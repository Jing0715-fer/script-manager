#!/usr/bin/env python3
"""
Script Manager Web Application
===============================
A web-based tool for managing, running, and analyzing scripts.
Features:
- Upload / Delete / List scripts
- Run scripts with uploaded input files → download results
- LLM-powered auto-analysis of script usage & one-click run config
- Script version/upgrade management
- Beautiful modern UI
"""

import os
import sys
import json
import shutil
import subprocess
import tempfile
import traceback
import uuid
import re
from datetime import datetime
from pathlib import Path
from functools import wraps

from flask import (
    Flask, render_template, request, jsonify,
    send_from_directory, send_file, abort
)

# ─── Configuration ───────────────────────────────────────────────
app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 500 * 1024 * 1024  # 500MB max upload

BASE_DIR = Path(__file__).parent.resolve()
SCRIPTS_DIR = BASE_DIR / 'scripts'
RESULTS_DIR = BASE_DIR / 'results'
CONFIGS_DIR = BASE_DIR / 'configs'
UPLOADS_DIR = BASE_DIR / 'uploads'

for d in [SCRIPTS_DIR, RESULTS_DIR, CONFIGS_DIR, UPLOADS_DIR]:
    d.mkdir(exist_ok=True)

# Also link user's local script folder for easy import
USER_SCRIPT_DIR = Path('/mnt/local/script')
USER_SCRIPT_AVAILABLE = USER_SCRIPT_DIR.exists()

# ─── Helpers ──────────────────────────────────────────────────────

def _script_path(name):
    p = SCRIPTS_DIR / name
    if not p.exists():
        abort(404, f"Script '{name}' not found")
    return p


def _config_path(name):
    return CONFIGS_DIR / f"{name}.json"


def _read_config(name):
    cp = _config_path(name)
    if cp.exists():
        return json.loads(cp.read_text('utf-8'))
    return None


def _write_config(name, cfg):
    _config_path(name).write_text(
        json.dumps(cfg, ensure_ascii=False, indent=2), 'utf-8'
    )


def _scan_scripts():
    """Return list of managed scripts with metadata."""
    items = []
    for f in sorted(SCRIPTS_DIR.iterdir()):
        if f.suffix in ('.py', '.sh', '.bash', '.rb', '.js', '.pl', '.R'):
            stat = f.stat()
            cfg = _read_config(f.name)
            items.append({
                'name': f.name,
                'size': stat.st_size,
                'mtime': datetime.fromtimestamp(stat.st_mtime).isoformat(),
                'config': cfg,
                'has_config': cfg is not None,
            })
    return items


def _safe_run(cmd, cwd, timeout=300, env=None):
    """Run a command safely, capture output."""
    merged = os.environ.copy()
    if env:
        merged.update(env)
    try:
        proc = subprocess.run(
            cmd, shell=True, cwd=str(cwd),
            capture_output=True, text=True, timeout=timeout,
            env=merged
        )
        return {
            'ok': proc.returncode == 0,
            'returncode': proc.returncode,
            'stdout': proc.stdout,
            'stderr': proc.stderr,
        }
    except subprocess.TimeoutExpired:
        return {'ok': False, 'returncode': -1, 'stdout': '', 'stderr': 'Timeout expired'}
    except Exception as e:
        return {'ok': False, 'returncode': -1, 'stdout': '', 'stderr': str(e)}


# ─── API Routes ───────────────────────────────────────────────────

# ---------- List ----------
@app.route('/api/scripts', methods=['GET'])
def api_list():
    return jsonify({'scripts': _scan_scripts(), 'user_dir_available': USER_SCRIPT_AVAILABLE})


@app.route('/api/user-scripts', methods=['GET'])
def api_user_scripts():
    """List scripts from user's local @script folder."""
    if not USER_SCRIPT_AVAILABLE:
        return jsonify({'scripts': [], 'path': str(USER_SCRIPT_DIR)})
    items = []
    for f in sorted(USER_SCRIPT_DIR.iterdir()):
        if f.is_file() and f.suffix in ('.py', '.sh', '.bash'):
            stat = f.stat()
            items.append({
                'name': f.name,
                'size': stat.st_size,
                'mtime': datetime.fromtimestamp(stat.mtime).isoformat(),
                'path': str(f),
            })
    return jsonify({'scripts': items, 'path': str(USER_SCRIPT_DIR)})


# ---------- Upload / Import ----------
@app.route('/api/scripts/upload', methods=['POST'])
def api_upload():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    f = request.files['file']
    if not f.filename:
        return jsonify({'error': 'Empty filename'}), 400
    dest = SCRIPTS_DIR / f.filename
    f.save(str(dest))
    return jsonify({'ok': True, 'name': f.filename})


@app.route('/api/scripts/import/<path:filename>', methods=['POST'])
def api_import(filename):
    """Import a script from user's local folder into managed store."""
    src = USER_SCRIPT_DIR / filename
    if not src.exists():
        return jsonify({'error': f'{filename} not found in user folder'}), 404
    dest = SCRIPTS_DIR / filename
    shutil.copy2(src, dest)
    return jsonify({'ok': True, 'name': filename})


# ---------- Read source ----------
@app.route('/api/scripts/<name>/source', methods=['GET'])
def api_source(name):
    p = _script_path(name)
    return {'source': p.read_text('utf-8', errors='replace')}


# ---------- Update (upgrade) ----------
@app.route('/api/scripts/<name>', methods=['PUT'])
def api_update(name):
    p = _script_path(name)
    data = request.get_json(silent=True) or {}
    if 'source' in data:
        p.write_text(data['source'], 'utf-8')
    if 'new_name' in data and data['new_name'] != name:
        new_p = SCRIPTS_DIR / data['new_name']
        if new_p.exists():
            return jsonify({'error': 'Target name already exists'}), 409
        p.rename(new_p)
        # Migrate config
        old_cfg = _config_path(name)
        if old_cfg.exists():
            old_cfg.rename(CONFIGS_DIR / f"{data['new_name']}.json")
        return jsonify({'ok': True, 'renamed': True, 'new_name': data['new_name']})
    return jsonify({'ok': True})


# ---------- Delete ----------
@app.route('/api/scripts/<name>', methods=['DELETE'])
def api_delete(name):
    p = _script_path(name)
    p.unlink(missing_ok=True)
    # Clean up config and results
    cp = _config_path(name)
    if cp.exists():
        cp.unlink()
    # Clean results for this script
    for rd in RESULTS_DIR.glob(f"{name}_*"):
        if rd.is_file():
            rd.unlink()
    return jsonify({'ok': True})


# ---------- Run ----------
@app.route('/api/scripts/<name>/run', methods=['POST'])
def api_run(name):
    p = _script_path(name)
    cfg = _read_config(name) or {}
    data = request.get_json(silent=True) or {}

    # Collect parameter overrides from frontend
    params = data.get('params', {})

    # Handle uploaded input files
    run_id = uuid.uuid4().hex[:12]
    work_dir = RESULTS_DIR / f"run_{run_id}_{name}"
    work_dir.mkdir(exist_ok=True)

    uploaded_files = {}
    if 'files' in request.files:
        # multipart form with files
        for key, uf in request.files.to_dict().items():
            fp = work_dir / uf.filename
            uf.save(str(fp))
            uploaded_files[key] = str(fp)
    elif data.get('uploaded_files'):
        # JSON list of base64 or pre-uploaded paths
        for fi in data['uploaded_files']:
            fp = work_dir / fi['name']
            fp.write_bytes(bytes.fromhex(fi.get('content_hex', '')) if fi.get('content_hex') else b'')
            uploaded_files[fi.get('key', fi['name'])] = str(fp)

    # Build command from config's run_template or default
    run_template = cfg.get('run_template')
    if not run_template:
        # Auto-detect: python script.py
        if p.suffix == '.py':
            run_template = 'python3 "{script}" {args}'
        elif p.suffix in ('.sh', '.bash'):
            run_template = 'bash "{script}" {args}'
        else:
            run_template = '"{script}" {args}'

    # Build args string from params + uploaded files
    args_parts = []
    param_defs = cfg.get('parameters', [])
    for pd in param_defs:
        pname = pd['name']
        pval = params.get(pname, pd.get('default', ''))
        if pval != '' and pval is not None:
            flag = pd.get('flag', '')
            if flag:
                args_parts.append(f"{flag} {pval}")
            else:
                args_parts.append(pval)

    # Add uploaded file paths as positional or flagged args
    file_param = cfg.get('file_input_param', '')
    for fk, fv in uploaded_files.items():
        if file_param:
            args_parts.append(f"{file_param} {fv}")
        else:
            args_parts.append(fv)

    args_str = ' '.join(args_parts)
    cmd = run_template.format(script=str(p), args=args_str)

    timeout = int(data.get('timeout', cfg.get('default_timeout', 300)))

    result = _safe_run(cmd, cwd=str(work_dir), timeout=timeout)

    # Collect output files produced
    output_files = []
    for out_f in work_dir.iterdir():
        if out_f.is_file():
            output_files.append({
                'name': out_f.name,
                'size': out_f.stat().st_size,
                'download_url': f'/api/results/{work_dir.name}/{out_f.name}',
            })

    resp = {
        'ok': result['ok'],
        'run_id': run_id,
        'cmd': cmd,
        'returncode': result['returncode'],
        'stdout': result['stdout'],
        'stderr': result['stderr'],
        'output_files': output_files,
        'work_dir': work_dir.name,
    }
    return jsonify(resp)


# ---------- Results Download ----------
@app.route('/api/results/<path:filepath>', methods=['GET'])
def api_download_result(filepath):
    fp = RESULTS_DIR / filepath
    if not fp.exists() or not fp.is_file():
        abort(404)
    return send_file(str(fp), as_attachment=True, download_name=fp.name)


# ---------- LLM Analysis ----------
@app.route('/api/scripts/<name>/analyze', methods=['POST'])
def api_analyze(name):
    """Analyze a script and generate run configuration using built-in parser.
    Falls back to calling external LLM API if configured."""
    p = _script_path(name)
    source = p.read_text('utf-8', errors='replace')

    # Step 1: Built-in static analysis
    analysis = _analyze_script_static(source, name)

    # Step 2: If user has OPENAI_API_KEY set, enrich with LLM
    llm_extra = None
    api_key = os.environ.get('OPENAI_API_KEY') or os.environ.get('LLM_API_KEY')
    if api_key:
        llm_extra = _call_llm_analyze(source, name, api_key)
        if llm_extra:
            analysis.update(llm_extra)

    # Save config
    _write_config(name, analysis)
    return jsonify({'ok': True, 'config': analysis, 'llm_enriched': bool(llm_extra)})


def _analyze_script_static(source, name):
    """Static analysis of script to extract usage info."""
    analysis = {
        'name': name,
        'description': '',
        'language': 'python' if name.endswith('.py') else 'shell',
        'parameters': [],
        'run_template': '',
        'file_input_param': '',
        'output_patterns': [],
        'dependencies': [],
        'default_timeout': 120,
        'analyzed_at': datetime.now().isoformat(),
    }

    lines = source.split('\n')

    # Extract docstring / description
    in_docstring = False
    doc_lines = []
    for i, line in enumerate(lines[:50]):  # Only check first 50 lines
        stripped = line.strip()
        if i == 0 and ('"""' in stripped or "'''" in stripped):
            in_docstring = True
            q = '"""' if '"""' in stripped else "'''"
            content = stripped.strip(q).strip()
            if content:
                doc_lines.append(content)
            # Check if it closes on same line
            if stripped.count(q) >= 2:
                in_docstring = False
            continue
        if in_docstring:
            q = '"""' if '"""' in lines[0] else "'''"
            if q in stripped:
                content = stripped[:stripped.index(q)].strip()
                if content:
                    doc_lines.append(content)
                in_docstring = False
            else:
                doc_lines.append(stripped)
            continue
        # Also look for # comments at top
        if not in_docstring and stripped.startswith('#') and len(doc_lines) == 0:
            comment_text = stripped.lstrip('#').strip()
            if comment_text and not comment_text.startswith('!') and not comment_text.startswith('-*-'):
                doc_lines.append(comment_text)
        elif stripped and not stripped.startswith('#') and len(doc_lines) == 0:
            break

    analysis['description'] = '\n'.join(doc_lines)[:2000]

    # Extract argparse / click parameters
    # Look for add_argument patterns
    arg_pattern = re.compile(
        r'add_argument\s*\(\s*["\'](-{1,2}[\w-]+)["\']'
        r'(?:\s*,\s*(?:dest|metavar|type|default|help|required|action|nargs|choices)\s*=\s*[^)]+)*'
        r'\)',
        re.MULTILINE
    )
    for m in arg_pattern.finditer(source):
        flag = m.group(1)
        # Try to extract help text
        full = m.group(0)
        help_m = re.search(r'help\s*=\s*["\']([^"\']*)["\']', full)
        type_m = re.search(r'type\s*=\s*(\w+)', full)
        default_m = re.search(r'default\s*=\s*([^,\)]+)', full)
        param = {
            'flag': flag,
            'name': flag.lstrip('-').replace('-', '_'),
            'help': help_m.group(1) if help_m else '',
            'type': type_m.group(1) if type_m else 'str',
            'default': default_m.group(1).strip() if default_m else '',
            'required': 'required' in full or '--' not in flag,
        }
        analysis['parameters'].append(param)

    # Look for sys.argv / input() / file open patterns
    if re.search(r'sys\.argv\s*\[', source) or re.search(r'argparse|click\.command', source):
        if name.endswith('.py'):
            analysis['run_template'] = 'python3 "{script}" {args}'

    # Look for file input hints
    file_hints = re.findall(r'(?:open|Path|input\s*\(\s*["\'][^"\']*\.(\w+))', source)
    exts = list(set(file_hints))
    analysis['input_file_types'] = exts[:10]

    # Look for output file patterns (split into safe sub-patterns)
    out_patterns = []
    out_patterns.extend(re.findall(r'open\(["\']([^"\']+)', source))
    out_patterns.extend(re.findall(r'to_\w+\(["\']([^"\']+)', source))
    out_patterns.extend(re.findall(r'savefig\(["\']([^"\']+)', source))
    # .write() calls without filename hints are skipped to avoid false positives
    flat = [p for p in out_patterns if p]
    analysis['output_patterns'] = list(set(flat))[:20]

    # Detect imports for dependencies
    imports = re.findall(r'^\s*(?:import|from)\s+(\w+)', source, re.MULTILINE)
    std_lib = {
        'os','sys','re','json','csv','math','random','datetime','collections',
        'itertools','functools','pathlib','subprocess','tempfile','argparse',
        'typing','abc','copy','io','string','textwrap','unicodedata','pprint',
        'hashlib','base64','uuid','time','logging','warnings','contextlib',
        'dataclasses','enum','numbers','fractions','decimal','operator',
        'array','bisect','heapq','weakref','types','inspect','dis','pickle',
        'shelve','sqlite3','unittest','doctest','threading','multiprocessing',
        'concurrent','socket','select','signal','email','html','xml',
        'webbrowser','cgi','cgitb','wsgiref','urllib','http','xmlrpc',
        'ftplib','poplib','imaplib','nntplib','smtplib','smtpd','uuid',
        'zipfile','tarfile','gzip','bz2','lzma','csv','configparser',
        'errno','getopt','getpass','platform','traceback','faulthandler',
        'optparse','pdb','cProfile','profile','timeit','stat',
    }
    third_party = [imp for imp in imports if imp not in std_lib]
    analysis['dependencies'] = list(set(third_party))

    return analysis


def _call_llm_analyze(source, name, api_key):
    """Call OpenAI-compatible API for deeper analysis."""
    try:
        import urllib.request
        import urllib.error

        base_url = os.environ.get('OPENAI_BASE_URL', 'https://api.openai.com/v1')
        model = os.environ.get('LLM_MODEL', 'gpt-4o-mini')

        prompt = f"""You are a script analysis expert. Analyze the following script and provide a JSON response with these fields (ONLY valid JSON, no markdown fences):

- description: A concise one-line description of what this script does (in Chinese if the script comments are Chinese, otherwise English)
- parameters: Array of {{name, flag, type, default, required, help, example_value}} for each CLI parameter
- run_template: The exact command template to run this script. Use {{script}} as placeholder for script path and {{args}} for arguments. Example: "python3 '{{{{script}}}}' --input {{args}}"
- file_input_param: Which parameter/flag accepts the main input file (empty if none)
- input_file_types: Expected input file extensions array (e.g., ["pdb","fasta"])
- output_patterns: What output files this script generates (glob patterns)
- notes: Any important usage notes or caveats
- tags: Relevant category tags array (e.g., ["bioinformatics", "visualization"])

Script name: {name}
Source code:
```python
{source[:8000]}
```

Respond ONLY with valid JSON object."""

        url = f"{base_url.rstrip('/')}/chat/completions"
        payload = json.dumps({
            'model': model,
            'messages': [
                {'role': 'system', 'content': 'You are a script analysis assistant. Always respond with valid JSON only.'},
                {'role': 'user', 'content': prompt},
            ],
            'temperature': 0.1,
            'max_tokens': 2000,
        }).encode('utf-8')

        req = urllib.request.Request(
            url, data=payload,
            headers={
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {api_key}',
            },
        )

        with urllib.request.urlopen(req, timeout=60) as resp:
            body = json.loads(resp.read().decode())
            content = body['choices'][0]['message']['content'].strip()
            # Strip markdown fences if present
            if content.startswith('```'):
                content = re.sub(r'^```(?:json)?\s*', '', content)
                content = re.sub(r'\s*```\s*$', '', content)
            return json.loads(content)

    except Exception as e:
        print(f"[LLM Analyze Error] {e}")
        return None


# ---------- Config CRUD ----------
@app.route('/api/scripts/<name>/config', methods=['GET'])
def api_get_config(name):
    cfg = _read_config(name)
    if not cfg:
        return jsonify({'error': 'No config found. Run analyze first.'}), 404
    return jsonify(cfg)


@app.route('/api/scripts/<name>/config', methods=['PUT'])
def api_put_config(name):
    data = request.get_json(silent=True) or {}
    existing = _read_config(name) or {}
    existing.update(data)
    existing['manual_edited_at'] = datetime.now().isoformat()
    _write_config(name, existing)
    return jsonify({'ok': True, 'config': existing})


# ---------- Batch operations ----------
@app.route('/api/scripts/batch-import', methods=['POST'])
def api_batch_import():
    """Import all .py/.sh files from user's local folder."""
    if not USER_SCRIPT_AVAILABLE:
        return jsonify({'error': 'User script folder not available'}), 400
    imported = []
    skipped = []
    for f in USER_SCRIPT_DIR.iterdir():
        if f.is_file() and f.suffix in ('.py', '.sh', '.bash'):
            dest = SCRIPTS_DIR / f.name
            if dest.exists():
                skipped.append(f.name)
            else:
                shutil.copy2(f, dest)
                imported.append(f.name)
    return jsonify({'ok': True, 'imported': imported, 'skipped': skipped})


# ─── Frontend Routes ──────────────────────────────────────────────

@app.route('/')
def index():
    return render_template('index.html')


# ─── Main ─────────────────────────────────────────────────────────

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5678))
    debug = os.environ.get('FLASK_DEBUG', '1') == '1'
    print(f"""
╔═══════════════════════════════════════════════════════════╗
║         🧩 Script Manager Web App                         ║
║   Access: http://localhost:{port}                           ║
║   Scripts dir: {str(SCRIPTS_DIR):<36} ║
╚═══════════════════════════════════════════════════════════╝
""")
    app.run(host='0.0.0.0', port=port, debug=debug)
