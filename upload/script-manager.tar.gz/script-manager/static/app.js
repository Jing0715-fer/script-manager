/* ═══════════════════════════════════════════════
   Script Manager — Frontend JavaScript
   ═══════════════════════════════════════════════ */

// ─── State ─────────────────────────────────────
const state = {
  scripts: [],
  userScripts: [],
  currentScript: null,
  currentSource: '',
  selectedRunFiles: [],
  view: 'scripts',
};

const API = '';

// ─── Init ──────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  refreshScriptList();
  loadUserScripts();
});

// ─── View Switching ────────────────────────────
function switchView(viewName) {
  state.view = viewName;
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
  const viewEl = document.getElementById(`view-${viewName}`);
  const tabEl = document.querySelector(`.nav-tab[data-view="${viewName}"]`);
  if (viewEl) viewEl.classList.add('active');
  if (tabEl) tabEl.classList.add('active');
}

// ─── Toast ─────────────────────────────────────
function toast(msg, type = 'info') {
  const c = document.getElementById('toast-container');
  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  el.textContent = msg;
  c.appendChild(el);
  setTimeout(() => el.remove(), 3000);
}

// ─── API Helpers ───────────────────────────────
async function api(method, path, body) {
  const opts = { method, headers: {} };
  if (body && method !== 'GET') {
    if (body instanceof FormData) {
      opts.body = body;
    } else {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    }
  }
  try {
    const res = await fetch(`${API}${path}`, opts);
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || data.message || `HTTP ${res.status}`);
    }
    return data;
  } catch (err) {
    toast(`请求失败: ${err.message}`, 'error');
    throw err;
  }
}

function fmtSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1048576).toFixed(1) + ' MB';
}

function timeAgo(iso) {
  try {
    const d = new Date(iso);
    const diff = Date.now() - d.getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return '刚刚';
    if (mins < 60) return mins + ' 分钟前';
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return hrs + ' 小时前';
    return Math.floor(hrs / 24) + ' 天前';
  } catch { return iso; }
}

// ─── Script List ──────────────────────────────
async function refreshScriptList() {
  const data = await api('GET', '/api/scripts');
  state.scripts = data.scripts || [];
  renderScriptList();
  updateStats(data.scripts || []);
  // Update run select
  updateRunSelect(state.scripts);
}

function renderScriptList(filterText) {
  const container = document.getElementById('script-list');
  let items = state.scripts;
  if (filterText) {
    const q = filterText.toLowerCase();
    items = items.filter(s => s.name.toLowerCase().includes(q)
      || (s.config && s.config.description && s.config.description.toLowerCase().includes(q)));
  }

  if (!items.length) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">📂</div>
        <p>${filterText ? '没有匹配的脚本' : '暂无脚本，请上传或从本地文件夹导入'}</p>
      </div>`;
    return;
  }

  container.innerHTML = items.map(s => {
    const cfg = s.config || {};
    const desc = cfg.description || '(暂无描述)';
    const tags = (cfg.tags || []).slice(0, 4);
    const langIcon = s.name.endsWith('.py') ? '🐍' : s.name.endsWith('.sh') ? '🖥️' : '📄';
    return `
      <div class="card" data-name="${escAttr(s.name)}">
        <div class="card-title">
          <span class="name" onclick="openDetail('${escAttr(s.name)}')">${langIcon} ${escHtml(s.name)}</span>
          ${s.has_config ? '<span class="badge badge-info">已配置</span>' : '<span class="badge badge-warning">未配置</span>'}
        </div>
        <div class="card-desc">${escHtml(desc)}</div>
        <div class="card-meta">
          <span>📦 ${fmtSize(s.size)}</span>
          <span>🕐 ${timeAgo(s.mtime)}</span>
          ${tags.length ? tags.map(t => `<span class="tag">${escHtml(t)}</span>`).join('') : ''}
        </div>
        <div class="card-actions">
          <button class="btn btn-sm btn-primary" onclick="quickRun('${escAttr(s.name)}')">▶️ 运行</button>
          <button class="btn btn-sm btn-outline" onclick="openDetail('${escAttr(s.name)}')">📝 编辑/查看</button>
          ${!s.has_config ? `<button class="btn btn-sm btn-outline" onclick="analyzeScript('${escAttr(s.name)}')">🔍 分析配置</button>` : ''}
        </div>
      </div>`;
  }).join('');
}

function filterScripts() {
  const q = document.getElementById('search-input').value;
  renderScriptList(q);
}

function updateStats(scripts) {
  const configured = scripts.filter(s => s.has_config).length;
  document.getElementById('stats-bar').innerHTML =
    `<span>共 ${scripts.length} 个脚本</span><span>${configured} 个已配置</span>`;
}

// ─── Upload ────────────────────────────────────
async function handleUpload(files) {
  if (!files || !files.length) return;
  let ok = 0, fail = 0;
  for (const f of files) {
    try {
      const fd = new FormData();
      fd.append('file', f);
      await api('POST', '/api/scripts/upload', fd);
      ok++;
    } catch { fail++; }
  }
  toast(`上传完成: ${ok} 成功, ${fail} 失败`, fail > 0 ? 'error' : 'success');
  refreshScriptList();
  // Reset input
  document.getElementById('upload-input').value = '';
}

// ─── Detail Modal ─────────────────────────────
async function openDetail(name) {
  state.currentScript = name;
  // Fetch source
  const srcData = await api('GET', `/api/scripts/${encodeURIComponent(name)}/source`);
  state.currentSource = srcData.source;

  // Find script metadata
  const meta = state.scripts.find(s => s.name === name);

  document.getElementById('detail-title').textContent = `脚本: ${name}`;
  document.getElementById('detail-meta').innerHTML = `
    <div class="detail-meta-item"><dt>文件名</dt><dd>${escHtml(name)}</dd></div>
    <div class="detail-meta-item"><dt>大小</dt><dd>${meta ? fmtSize(meta.size) : '-'}</dd></div>
    <div class="detail-meta-item"><dt>修改时间</dt><dd>${meta ? timeAgo(meta.mtime) : '-'}</dd></div>
    <div class="detail-meta-item"><dt>状态</dt><dd>${meta && meta.has_config ? '<span class="text-green">✅ 已配置运行参数</span>' : '<span class="text-warning">⚠️ 未配置（建议分析）</span>'}</dd></div>
  `;
  document.getElementById('source-editor').value = state.currentSource;

  // Show config editor if exists
  const cfgEl = document.getElementById('config-editor');
  if (meta && meta.config) {
    cfgEl.style.display = 'block';
    document.getElementById('config-json').value = JSON.stringify(meta.config, null, 2);
  } else {
    cfgEl.style.display = 'none';
  }

  showModal('modal-detail');
}

async function saveSource() {
  if (!state.currentScript) return;
  const source = document.getElementById('source-editor').value;
  await api('PUT', `/api/scripts/${encodeURIComponent(state.currentScript)}`, { source });
  toast('✅ 源代码已保存', 'success');
  refreshScriptList();
}

async function saveConfig() {
  if (!state.currentScript) return;
  try {
    const cfg = JSON.parse(document.getElementById('config-json').value);
    await api('PUT', `/api/scripts/${encodeURIComponent(state.currentScript)}/config`, cfg);
    toast('✅ 配置已保存', 'success');
    refreshScriptList();
  } catch (e) {
    toast('❌ JSON 格式错误: ' + e.message, 'error');
  }
}

async function deleteCurrentScript() {
  if (!state.currentScript) return;
  if (!confirm(`确定要删除 "${state.currentScript}" 吗？此操作不可撤销。`)) return;
  await api('DELETE', `/api/scripts/${encodeURIComponent(state.currentScript)}`);
  toast('🗑️ 脚本已删除', 'info');
  hideModal('modal-detail');
  refreshScriptList();
}

// ─── Run Script ───────────────────────────────
function updateRunSelect(scripts) {
  const sel = document.getElementById('run-script-select');
  const cur = sel.value;
  sel.innerHTML = '<option value="">-- 请选择一个脚本 --</option>'
    + scripts.map(s => `<option value="${escAttr(s.name)}">${escHtml(s.name)}</option>`).join('');
  if (scripts.find(s => s.name === cur)) sel.value = cur;
}

function quickRun(name) {
  switchView('run');
  document.getElementById('run-script-select').value = name;
  onSelectRunScript(name);
}

let currentRunConfig = null;

function onSelectRunScript(name) {
  if (!name) {
    document.getElementById('run-config-area').style.display = 'none';
    return;
  }
  state.currentScript = name;
  const meta = state.scripts.find(s => s.name === name);
  currentRunConfig = meta ? meta.config : null;

  // Show config area
  document.getElementById('run-config-area').style.display = 'block';

  // Info card
  const infoCard = document.getElementById('script-info-card');
  if (currentRunConfig) {
    infoCard.innerHTML = `
      <h4>📋 ${escHtml(currentRunConfig.description || name)}</h4>
      <p>${escHtml((currentRunConfig.notes || '').substring(0, 300))}</p>
      <div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap;">
        ${(currentRunConfig.tags || []).map(t => `<span class="tag">${escHtml(t)}</span>`).join('')}
        ${(currentRunConfig.dependencies || []).map(d => `<span class="badge badge-warning">${escHtml(d)}</span>`).join('')}
      </div>`;
  } else {
    infoCard.innerHTML = `
      <h4>⚙️ ${escHtml(name)}</h4>
      <p class="text-muted">该脚本尚未进行 LLM 分析配置，点击 "LLM 分析配置" 自动生成运行参数。</p>
      <p class="text-muted" style="margin-top:4px;">也可直接上传文件后运行（将使用默认命令模板）。</p>`;
  }

  // Parameters form
  renderParamsForm(currentRunConfig);

  // Reset output
  document.getElementById('run-output').style.display = 'none';
  state.selectedRunFiles = [];
  renderSelectedFiles();
}

function renderParamsForm(cfg) {
  const container = document.getElementById('params-form');
  const params = (cfg && cfg.parameters) || [];
  if (!params.length) {
    container.innerHTML = '<p class="text-muted" style="font-size:12.5px;padding:8px 0;">无需额外参数，可直接运行或上传输入文件。</p>';
    return;
  }
  container.innerHTML = '<h4 style="font-size:13px;margin-bottom:10px;color:var(--fg2);">📌 运行参数</h4>'
    + params.map(p => `
      <div class="param-row">
        <label>${escHtml(p.flag || p.name)}</label>
        ${p.type === 'bool' || p.action === 'store_true'
          ? `<input type="checkbox" id="param_${escAttr(p.name)}" ${p.default ? 'checked' : ''}>`
          : `<input type="text" id="param_${escAttr(p.name)}"
              placeholder="${escHtml(p.help || '')}"
              value="${escAttr(p.default || '')}"
              ${p.required ? 'required' : ''}>`
        }
      </div>
      ${p.help ? `<div class="param-help">${escHtml(p.help)}</div>` : ''}
    `).join('');
}

function getParamValues() {
  const params = (currentRunConfig && currentRunConfig.parameters) || {};
  const values = {};
  for (const p of params) {
    const el = document.getElementById(`param_${p.name}`);
    if (!el) continue;
    if (p.type === 'bool' || p.action === 'store_true') {
      values[p.name] = el.checked;
    } else {
      values[p.name] = el.value;
    }
  }
  return values;
}

// File handling for run
function handleDrop(ev) {
  ev.preventDefault();
  document.getElementById('drop-zone').classList.remove('drag-over');
  const files = ev.dataTransfer.files;
  handleRunFiles(files);
}

function handleRunFiles(files) {
  if (!files || !files.length) return;
  for (const f of files) {
    state.selectedRunFiles.push(f);
  }
  renderSelectedFiles();
}

function renderSelectedFiles() {
  const c = document.getElementById('selected-files');
  if (!state.selectedRunFiles.length) {
    c.innerHTML = '';
    return;
  }
  c.innerHTML = '<div style="font-size:11.5px;color:var(--fg3);margin-bottom:4px;">已选文件:</div>'
    + state.selectedRunFiles.map((f, i) => `
      <div class="file-item-mini">
        📎 ${escHtml(f.name)} (${fmtSize(f.size)})
        <button class="remove-btn" onclick="removeRunFile(${i})">✕</button>
      </div>
    `).join('');
}

function removeRunFile(idx) {
  state.selectedRunFiles.splice(idx, 1);
  renderSelectedFiles();
}

// Execute Run
async function executeRun() {
  const name = state.currentScript;
  if (!name) { toast('请先选择一个脚本', 'error'); return; }

  const btn = document.getElementById('btn-run');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> 运行中...';

  try {
    const timeout = parseInt(document.getElementById('run-timeout').value) || 120;
    const params = getParamValues();

    // Build form data with files
    const fd = new FormData();
    fd.append('json', JSON.stringify({ params, timeout }));
    for (const f of state.selectedRunFiles) {
      fd.append('files', f);
    }

    const resp = await fetch(`${API}/api/scripts/${encodeURIComponent(name)}/run`, {
      method: 'POST',
      body: fd,
    });
    const data = await resp.json();

    // Show output
    showRunOutput(data);
  } catch (err) {
    toast('运行失败: ' + err.message, 'error');
  } finally {
    btn.disabled = false;
    btn.innerHTML = '▶️ 运行脚本';
  }
}

function showRunOutput(data) {
  const area = document.getElementById('run-output');
  area.style.display = 'block';

  const badge = document.getElementById('run-status-badge');
  badge.className = 'badge ' + (data.ok ? 'badge-success' : 'badge-error');
  badge.textContent = data.ok ? '✅ 成功' : `❌ 失败 (exit code: ${data.returncode})`;

  document.getElementById('run-stdout').textContent = data.stdout || '(无标准输出)';
  document.getElementById('run-stderr').textContent = data.stderr || '(无错误输出)';

  // Result files
  const rf = document.getElementById('result-files');
  if (data.output_files && data.output_files.length) {
    rf.innerHTML = '<span style="font-size:12px;color:var(--fg2);width:100%;margin-bottom:4px;">📦 输出文件：</span>'
      + data.output_files.map(f =>
        `<a class="result-file-btn" href="${escAttr(f.download_url)}" download="${escAttr(f.name)}">
           📥 ${escHtml(f.name)} (${fmtSize(f.size)})
         </a>`
      ).join('');
  } else {
    rf.innerHTML = '<span style="font-size:12px;color:var(--fg3);">无输出文件</span>';
  }

  // Scroll to output
  area.scrollIntoView({ behavior: 'smooth', block: 'start' });

  if (data.ok) {
    toast('✅ 脚本执行成功！', 'success');
  } else {
    toast('⚠️ 脚本执行出错', 'error');
  }
}

// ─── LLM Analyze ──────────────────────────────
async function analyzeScript(name) {
  try {
    toast('🔍 正在分析脚本...', 'info');
    const data = await api('POST', `/api/scripts/${encodeURIComponent(name)}/analyze`);
    toast(
      data.llm_enriched ? '✅ LLM 分析完成！' : '✅ 基础分析完成（设置 OPENAI_API_KEY 可启用深度分析）',
      'success'
    );
    refreshScriptList();
    // If we're on run view, reload the config
    if (state.currentScript === name) {
      onSelectRunScript(name);
    }
  } catch (err) {
    toast('分析失败: ' + err.message, 'error');
  }
}

function analyzeCurrentScript() {
  if (!state.currentScript) { toast('请先选择一个脚本', 'error'); return; }
  analyzeScript(state.currentScript);
}

// ─── User Folder Browser ──────────────────────
async function loadUserScripts() {
  const data = await api('GET', '/api/user-scripts');
  state.userScripts = data.scripts || [];

  const label = document.getElementById('user-path-label');
  label.textContent = data.path || '不可用';

  const container = document.getElementById('user-script-list');
  if (!state.userScripts.length) {
    container.innerHTML = `<div class="empty-state"><div class="empty-icon">📁</div><p>本地文件夹为空或不可用</p></div>`;
    return;
  }

  container.innerHTML = state.userScripts.map(s => `
    <div class="card">
      <div class="card-title">
        <span class="name">${s.name.endsWith('.py') ? '🐍' : '🖥️'} ${escHtml(s.name)}</span>
      </div>
      <div class="card-meta">
        <span>📦 ${fmtSize(s.size)}</span>
        <span>🕐 ${timeAgo(s.mtime)}</span>
      </div>
      <div class="card-actions">
        <button class="btn btn-sm btn-primary" onclick="importSingle('${escAttr(s.name)}')">📥 导入到管理器</button>
      </div>
    </div>
  `).join('');
}

async function importSingle(name) {
  try {
    await api('POST', `/api/scripts/import/${encodeURIComponent(name)}`);
    toast(`✅ 已导入 ${name}`, 'success');
    refreshScriptList();
  } catch (err) {
    toast('导入失败: ' + err.message, 'error');
  }
}

async function batchImport() {
  try {
    const data = await api('POST', '/api/scripts/batch-import');
    const msg = [];
    if (data.imported.length) msg.push(`成功导入 ${data.imported.length} 个: ${data.imported.join(', ')}`);
    if (data.skipped.length) msg.push(`跳过 ${data.skipped.length} 个(已存在): ${data.skipped.join(', ')}`);
    toast(msg.join('; '), data.skipped.length && !data.imported.length ? 'error' : 'success');
    document.getElementById('batch-result').innerHTML = msg.join('<br>');
    refreshScriptList();
  } catch (err) {
    toast('批量导入失败: ' + err.message, 'error');
  }
}

// ─── Modal helpers ─────────────────────────────
function showModal(id) {
  document.getElementById(id).style.display = 'flex';
}
function hideModal(id) {
  document.getElementById(id).style.display = 'none';
}
function closeModalOnBg(e, id) {
  if (e.target === e.currentTarget) hideModal(id);
}

// ─── Utils ─────────────────────────────────────
function escHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
function escAttr(str) {
  return String(str).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/'/g,'&#39;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
