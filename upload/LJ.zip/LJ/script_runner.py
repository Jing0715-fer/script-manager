#!/usr/bin/env python3
"""
Script Runner - Professional script UI interface based on PyQt5

Features:
1. Modern and beautiful interface
2. Script management and execution
3. Real-time output display
4. Error capture and display
5. Configuration management
6. Script parameter templates
"""

import sys
import os
import json
import subprocess

# Check PyQt5 installation first
try:
    from PyQt5.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QLabel, QLineEdit, QPushButton, QListWidget, QListWidgetItem,
        QTextEdit, QFileDialog, QTabWidget, QGroupBox, QFormLayout,
        QSpinBox, QDoubleSpinBox, QCheckBox, QComboBox, QMessageBox
    )
    from PyQt5.QtCore import Qt, QProcess, QTimer
    from PyQt5.QtGui import QFont, QIcon, QTextCursor
    PYQT5_AVAILABLE = True
except ImportError:
    PYQT5_AVAILABLE = False

class ScriptRunner(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Script Runner")
        self.setGeometry(100, 100, 900, 700)
        self.setMinimumSize(800, 600)
        
        # Configuration file
        self.config_file = "script_runner_config.json"
        
        # Process object
        self.process = QProcess()
        
        # Initialize UI
        self.init_ui()
        
        # Load configuration
        self.load_config()
    
    def init_ui(self):
        """Initialize user interface"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QVBoxLayout(central_widget)
        
        # Create tab widget
        self.tab_widget = QTabWidget()
        
        # Main tab - Script execution
        self.main_tab = QWidget()
        self.tab_widget.addTab(self.main_tab, "Script Execution")
        
        # Config tab
        self.config_tab = QWidget()
        self.tab_widget.addTab(self.config_tab, "Configuration")
        
        main_layout.addWidget(self.tab_widget)
        
        # Initialize main tab
        self.init_main_tab()
        
        # Initialize config tab
        self.init_config_tab()
    
    def init_main_tab(self):
        """Initialize main tab"""
        layout = QVBoxLayout(self.main_tab)
        
        # Script selection area
        script_group = QGroupBox("Script Selection")
        script_layout = QFormLayout(script_group)
        
        # Script path
        self.script_path_edit = QLineEdit()
        browse_button = QPushButton("Browse...")
        browse_button.clicked.connect(self.browse_script)
        
        path_layout = QHBoxLayout()
        path_layout.addWidget(self.script_path_edit)
        path_layout.addWidget(browse_button)
        
        script_layout.addRow("Script Path:", path_layout)
        
        # Recent scripts
        self.recent_scripts = QListWidget()
        self.recent_scripts.itemClicked.connect(self.on_script_clicked)
        script_layout.addRow("Recent:", self.recent_scripts)
        
        layout.addWidget(script_group)
        
        # Parameter settings area
        param_group = QGroupBox("Parameter Settings")
        param_layout = QFormLayout(param_group)
        
        # Working directory
        self.workdir_edit = QLineEdit()
        workdir_button = QPushButton("Browse...")
        workdir_button.clicked.connect(self.browse_workdir)
        
        workdir_layout = QHBoxLayout()
        workdir_layout.addWidget(self.workdir_edit)
        workdir_layout.addWidget(workdir_button)
        
        param_layout.addRow("Work Directory:", workdir_layout)
        
        # Parameter input
        self.params_edit = QLineEdit()
        param_layout.addRow("Command Parameters:", self.params_edit)
        
        layout.addWidget(param_group)
        
        # Run control area
        control_group = QGroupBox("Run Control")
        control_layout = QHBoxLayout(control_group)
        
        self.run_button = QPushButton("Run Script")
        self.run_button.clicked.connect(self.run_script)
        control_layout.addWidget(self.run_button)
        
        self.stop_button = QPushButton("Stop Execution")
        self.stop_button.clicked.connect(self.stop_script)
        self.stop_button.setEnabled(False)
        control_layout.addWidget(self.stop_button)
        
        self.clear_button = QPushButton("Clear Output")
        self.clear_button.clicked.connect(self.clear_output)
        control_layout.addWidget(self.clear_button)
        
        self.save_button = QPushButton("Save Config")
        self.save_button.clicked.connect(self.save_config)
        control_layout.addWidget(self.save_button)
        
        layout.addWidget(control_group)
        
        # Output display area
        output_group = QGroupBox("Run Output")
        output_layout = QVBoxLayout(output_group)
        
        self.output_text = QTextEdit()
        self.output_text.setReadOnly(True)
        self.output_text.setFont(QFont("Consolas", 10))
        output_layout.addWidget(self.output_text)
        
        layout.addWidget(output_group, 1)
    
    def init_config_tab(self):
        """Initialize config tab"""
        layout = QVBoxLayout(self.config_tab)
        
        # Configuration area
        config_group = QGroupBox("Program Configuration")
        config_layout = QFormLayout(config_group)
        
        # Output buffer size
        self.buffer_size = QSpinBox()
        self.buffer_size.setRange(1024, 65536)
        self.buffer_size.setValue(4096)
        config_layout.addRow("Output Buffer Size:", self.buffer_size)
        
        # Auto save config
        self.auto_save = QCheckBox()
        self.auto_save.setChecked(True)
        config_layout.addRow("Auto Save Config:", self.auto_save)
        
        # Show timestamp
        self.show_timestamp = QCheckBox()
        self.show_timestamp.setChecked(True)
        config_layout.addRow("Show Timestamp:", self.show_timestamp)
        
        layout.addWidget(config_group)
        
        # Script template area
        template_group = QGroupBox("Script Templates")
        template_layout = QVBoxLayout(template_group)
        
        self.template_list = QListWidget()
        template_layout.addWidget(self.template_list)
        
        template_buttons = QHBoxLayout()
        add_template = QPushButton("Add Template")
        remove_template = QPushButton("Remove Template")
        template_buttons.addWidget(add_template)
        template_buttons.addWidget(remove_template)
        
        template_layout.addLayout(template_buttons)
        
        layout.addWidget(template_group)
    
    def browse_script(self):
        """Browse script files"""
        file_types = "Python Scripts (*.py);;Shell Scripts (*.sh);;Batch Scripts (*.bat);;All Files (*.*)"
        script_path, _ = QFileDialog.getOpenFileName(
            self, "Select Script File", 
            os.path.dirname(self.script_path_edit.text()) or os.getcwd(),
            file_types
        )
        
        if script_path:
            self.script_path_edit.setText(script_path)
            self.update_recent_scripts(script_path)
    
    def browse_workdir(self):
        """Browse working directory"""
        workdir = QFileDialog.getExistingDirectory(
            self, "Select Working Directory",
            self.workdir_edit.text() or os.getcwd()
        )
        
        if workdir:
            self.workdir_edit.setText(workdir)
    
    def on_script_clicked(self, item):
        """Click script list item"""
        script_path = item.text()
        self.script_path_edit.setText(script_path)
    
    def update_recent_scripts(self, script_path):
        """Update recent scripts list"""
        # Remove existing item
        for i in range(self.recent_scripts.count()):
            if self.recent_scripts.item(i).text() == script_path:
                self.recent_scripts.takeItem(i)
                break
        
        # Add to beginning
        item = QListWidgetItem(script_path)
        self.recent_scripts.insertItem(0, item)
        
        # Limit list length
        while self.recent_scripts.count() > 10:
            self.recent_scripts.takeItem(self.recent_scripts.count() - 1)
    
    def run_script(self):
        """Run script"""
        script_path = self.script_path_edit.text()
        
        if not script_path:
            QMessageBox.warning(self, "Error", "Please select script file")
            return
        
        if not os.path.exists(script_path):
            QMessageBox.warning(self, "Error", f"Script file does not exist: {script_path}")
            return
        
        workdir = self.workdir_edit.text()
        if not workdir:
            workdir = os.path.dirname(script_path)
        
        if not os.path.exists(workdir):
            QMessageBox.warning(self, "Error", f"Working directory does not exist: {workdir}")
            return
        
        # Prepare command
        if script_path.endswith('.py'):
            cmd = [sys.executable, script_path]
        else:
            cmd = [script_path]
        
        # Add parameters
        params = self.params_edit.text().strip()
        if params:
            cmd.extend(params.split())
        
        # Update recent scripts
        self.update_recent_scripts(script_path)
        
        # Save config
        if self.auto_save.isChecked():
            self.save_config()
        
        # Clear output
        self.clear_output()
        
        # Show run information
        self.append_output(f"=== Run Information ===\n")
        self.append_output(f"Script: {script_path}\n")
        self.append_output(f"Command: {' '.join(cmd)}\n")
        self.append_output(f"Work Directory: {workdir}\n")
        self.append_output(f"=== Output Started ===\n")
        
        # Disable run button, enable stop button
        self.run_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        
        # Run script
        self.process = QProcess()
        self.process.setWorkingDirectory(workdir)
        self.process.readyReadStandardOutput.connect(self.read_output)
        self.process.readyReadStandardError.connect(self.read_error)
        self.process.finished.connect(self.process_finished)
        self.process.start(cmd[0], cmd[1:])
    
    def stop_script(self):
        """Stop script execution"""
        if self.process and self.process.state() == QProcess.Running:
            self.process.kill()
            self.append_output("\n=== Script stopped by user ===\n")
    
    def read_output(self):
        """Read standard output"""
        output = self.process.readAllStandardOutput().data().decode('utf-8', 'ignore')
        self.append_output(output)
    
    def read_error(self):
        """Read standard error"""
        error = self.process.readAllStandardError().data().decode('utf-8', 'ignore')
        self.append_output(f"[ERROR] {error}")
    
    def process_finished(self, exit_code, exit_status):
        """Process finished"""
        self.append_output(f"\n=== Run Finished ===\n")
        self.append_output(f"Exit Code: {exit_code}\n")
        if exit_code == 0:
            self.append_output(f"Status: Success\n")
        else:
            self.append_output(f"Status: Failed\n")
        
        # Restore button state
        self.run_button.setEnabled(True)
        self.stop_button.setEnabled(False)
    
    def append_output(self, text):
        """Append output to text box"""
        if self.show_timestamp.isChecked():
            import datetime
            timestamp = datetime.datetime.now().strftime("[%H:%M:%S] ")
            text = timestamp + text
        
        self.output_text.insertPlainText(text)
        self.output_text.moveCursor(QTextCursor.End)
    
    def clear_output(self):
        """Clear output"""
        self.output_text.clear()
    
    def save_config(self):
        """Save configuration"""
        config = {
            "script_path": self.script_path_edit.text(),
            "workdir": self.workdir_edit.text(),
            "params": self.params_edit.text(),
            "buffer_size": self.buffer_size.value(),
            "auto_save": self.auto_save.isChecked(),
            "show_timestamp": self.show_timestamp.isChecked(),
            "recent_scripts": []
        }
        
        # Save recent scripts
        for i in range(self.recent_scripts.count()):
            config["recent_scripts"].append(self.recent_scripts.item(i).text())
        
        try:
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
            self.append_output(f"Config saved to: {self.config_file}\n")
        except Exception as e:
            self.append_output(f"Failed to save config: {str(e)}\n")
    
    def load_config(self):
        """Load configuration"""
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, "r", encoding="utf-8") as f:
                    config = json.load(f)
                
                # Restore config
                if "script_path" in config:
                    self.script_path_edit.setText(config["script_path"])
                
                if "workdir" in config:
                    self.workdir_edit.setText(config["workdir"])
                else:
                    self.workdir_edit.setText(os.getcwd())
                
                if "params" in config:
                    self.params_edit.setText(config["params"])
                
                if "buffer_size" in config:
                    self.buffer_size.setValue(config["buffer_size"])
                
                if "auto_save" in config:
                    self.auto_save.setChecked(config["auto_save"])
                
                if "show_timestamp" in config:
                    self.show_timestamp.setChecked(config["show_timestamp"])
                
                if "recent_scripts" in config:
                    self.recent_scripts.clear()
                    for script in config["recent_scripts"]:
                        self.recent_scripts.addItem(script)
                
            except Exception as e:
                self.append_output(f"Failed to load config: {str(e)}\n")
    
    def closeEvent(self, event):
        """Window close event"""
        if self.auto_save.isChecked():
            self.save_config()
        event.accept()

def main():
    """Main function"""
    # Check PyQt5 installation
    if not PYQT5_AVAILABLE:
        print("Error: PyQt5 is not installed")
        print("Please run: pip install PyQt5")
        return
    
    app = QApplication(sys.argv)
    window = ScriptRunner()
    window.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()