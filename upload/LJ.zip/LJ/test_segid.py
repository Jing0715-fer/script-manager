#!/usr/bin/env python3

import subprocess
import sys

# Test segID.py with a simple PDB file
test_pdb = """ATOM      1  N   ALA A   1      26.510  32.830  11.530  1.00  0.00           N  
ATOM      2  CA  ALA A   1      27.680  32.000  10.870  1.00  0.00           C  
ATOM      3  C   ALA A   1      27.310  30.500  10.710  1.00  0.00           C  
ATOM      4  O   ALA A   1      26.140  30.170  10.470  1.00  0.00           O  
ATOM      5  CB  ALA A   1      28.990  31.820  11.790  1.00  0.00           C  
END
"""

# Write test PDB file
with open("test.pdb", "w") as f:
    f.write(test_pdb)

# Run segID.py
try:
    result = subprocess.run(
        [sys.executable, "/mnt/d/script/segID.py", "test.pdb", "test_output.pdb"],
        capture_output=True,
        text=True,
        check=True
    )
    print("segID.py ran successfully!")
    print("Output:", result.stdout)
    print("Error:", result.stderr)
    
    # Check output file
    if os.path.exists("test_output.pdb"):
        print("\nOutput file created successfully!")
        with open("test_output.pdb", "r") as f:
            print("Output file content:")
            print(f.read())
except subprocess.CalledProcessError as e:
    print("segID.py failed to run:")
    print("Exit code:", e.returncode)
    print("Output:", e.stdout)
    print("Error:", e.stderr)
except Exception as e:
    print("Error running segID.py:", str(e))