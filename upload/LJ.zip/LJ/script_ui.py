#!/usr/bin/env python3
"""
Script UI - Interactive user interface for terminal scripts

Features:
1. Browse and select script files
2. Automatic script parameter detection and display
3. Attachment upload functionality
4. File auto-processing for script inputs
5. Run scripts and display output
6. Save and load configurations
"""

import tkinter as tk
from tkinter import filedialog, ttk, scrolledtext, messagebox
import subprocess
import os
import json
import sys
import re
import argparse

class ScriptUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Script Runner Pro")
        self.root.geometry("900x700")
        self.root.minsize(700, 500)
        
        # Configuration file
        self.config_file = "script_ui_config.json"
        
        # Script directory
        self.script_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Upload directory
        self.upload_dir = os.path.join(self.script_dir, "uploads")
        if not os.path.exists(self.upload_dir):
            os.makedirs(self.upload_dir)
        
        # Create main frame
        self.main_frame = ttk.Frame(self.root, padding="10")
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create widgets
        self.create_widgets()
        
        # Load configuration
        self.load_config()
    
    def create_widgets(self):
        # Top frame - Script selection
        top_frame = ttk.LabelFrame(self.main_frame, text="Script Selection", padding="10")
        top_frame.pack(fill=tk.X, pady=5)
        
        # Script path input
        ttk.Label(top_frame, text="Script Path:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.script_path_var = tk.StringVar()
        self.script_path_entry = ttk.Entry(top_frame, textvariable=self.script_path_var, width=60)
        self.script_path_entry.grid(row=0, column=1, sticky=tk.W, pady=5, padx=5)
        self.script_path_var.trace_add("write", self.on_script_changed)
        
        # Browse button
        ttk.Button(top_frame, text="Browse", command=self.browse_script).grid(row=0, column=2, pady=5, padx=5)
        
        # Load parameters button
        ttk.Button(top_frame, text="Load Params", command=self.detect_script_parameters).grid(row=0, column=3, pady=5, padx=5)
        
        # Script list
        ttk.Label(top_frame, text="Recent:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.script_listbox = tk.Listbox(top_frame, width=60, height=5)
        self.script_listbox.grid(row=1, column=1, sticky=tk.W, pady=5, padx=5)
        self.script_listbox.bind("<<ListboxSelect>>", self.on_script_select)
        
        # Middle frame - Parameter input
        param_frame = ttk.LabelFrame(self.main_frame, text="Parameter Settings", padding="10")
        param_frame.pack(fill=tk.X, pady=5)
        
        # Parameter input
        ttk.Label(param_frame, text="Parameters:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.params_var = tk.StringVar()
        self.params_entry = ttk.Entry(param_frame, textvariable=self.params_var, width=60)
        self.params_entry.grid(row=0, column=1, sticky=tk.W, pady=5, padx=5)
        
        # Working directory
        ttk.Label(param_frame, text="Work Dir:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.workdir_var = tk.StringVar(value=os.getcwd())
        self.workdir_entry = ttk.Entry(param_frame, textvariable=self.workdir_var, width=60)
        self.workdir_entry.grid(row=1, column=1, sticky=tk.W, pady=5, padx=5)
        
        # Browse button
        ttk.Button(param_frame, text="Browse", command=self.browse_workdir).grid(row=1, column=2, pady=5, padx=5)
        
        # Attachment frame
        attach_frame = ttk.LabelFrame(self.main_frame, text="Attachments", padding="10")
        attach_frame.pack(fill=tk.X, pady=5)
        
        # Attachment list
        self.attach_listbox = tk.Listbox(attach_frame, width=80, height=5)
        self.attach_listbox.grid(row=0, column=0, columnspan=2, sticky=tk.W, pady=5, padx=5)
        
        # Attachment buttons
        attach_buttons = ttk.Frame(attach_frame)
        attach_buttons.grid(row=1, column=0, columnspan=2, pady=5)
        
        ttk.Button(attach_buttons, text="Upload File", command=self.upload_file).pack(side=tk.LEFT, pady=5, padx=5)
        ttk.Button(attach_buttons, text="Remove File", command=self.remove_attachment).pack(side=tk.LEFT, pady=5, padx=5)
        ttk.Button(attach_buttons, text="Clear All", command=self.clear_attachments).pack(side=tk.LEFT, pady=5, padx=5)
        
        # Detected parameters frame
        self.detected_params_frame = ttk.LabelFrame(self.main_frame, text="Detected Parameters", padding="10")
        self.detected_params_frame.pack(fill=tk.X, pady=5)
        
        # Detected parameters content
        self.params_content_frame = ttk.Frame(self.detected_params_frame)
        self.params_content_frame.pack(fill=tk.BOTH, expand=True)
        
        # Bottom frame - Run control
        bottom_frame = ttk.LabelFrame(self.main_frame, text="Run Control", padding="10")
        bottom_frame.pack(fill=tk.X, pady=5)
        
        # Run button
        self.run_button = ttk.Button(bottom_frame, text="Run Script", command=self.run_script)
        self.run_button.pack(side=tk.LEFT, pady=5, padx=5)
        
        # Stop button
        self.stop_button = ttk.Button(bottom_frame, text="Stop", command=self.stop_script, state=tk.DISABLED)
        self.stop_button.pack(side=tk.LEFT, pady=5, padx=5)
        
        # Clear button
        ttk.Button(bottom_frame, text="Clear Output", command=self.clear_output).pack(side=tk.LEFT, pady=5, padx=5)
        
        # Save config button
        ttk.Button(bottom_frame, text="Save Config", command=self.save_config).pack(side=tk.RIGHT, pady=5, padx=5)
        
        # Output frame
        output_frame = ttk.LabelFrame(self.main_frame, text="Run Output", padding="10")
        output_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # Output text box
        self.output_text = scrolledtext.ScrolledText(output_frame, height=15, wrap=tk.WORD)
        self.output_text.pack(fill=tk.BOTH, expand=True)
        
        # Process variable
        self.process = None
        
        # Detected parameters
        self.detected_params = {}
        self.param_widgets = {}
    
    def browse_script(self):
        """Browse script files"""
        filetypes = [
            ("Python Scripts", "*.py"),
            ("Shell Scripts", "*.sh"),
            ("Batch Scripts", "*.bat"),
            ("All Files", "*.*")
        ]
        filename = filedialog.askopenfilename(
            initialdir=self.script_dir,
            title="Select Script File",
            filetypes=filetypes
        )
        if filename:
            self.script_path_var.set(filename)
            self.update_script_list(filename)
            self.detect_script_parameters()
    
    def browse_workdir(self):
        """Browse working directory"""
        directory = filedialog.askdirectory(
            initialdir=self.workdir_var.get(),
            title="Select Working Directory"
        )
        if directory:
            self.workdir_var.set(directory)
    
    def on_script_select(self, event):
        """Select item from script list"""
        selection = event.widget.curselection()
        if selection:
            index = selection[0]
            script_path = event.widget.get(index)
            self.script_path_var.set(script_path)
            self.detect_script_parameters()
    
    def on_script_changed(self, *args):
        """When script path changes"""
        script_path = self.script_path_var.get()
        if script_path and os.path.exists(script_path):
            self.detect_script_parameters()
    
    def update_script_list(self, script_path):
        """Update script list"""
        # Read current list
        scripts = []
        for i in range(self.script_listbox.size()):
            scripts.append(self.script_listbox.get(i))
        
        # If script exists, move to beginning
        if script_path in scripts:
            scripts.remove(script_path)
        
        # Add to beginning
        scripts.insert(0, script_path)
        
        # Limit list length
        scripts = scripts[:10]
        
        # Update listbox
        self.script_listbox.delete(0, tk.END)
        for script in scripts:
            self.script_listbox.insert(tk.END, script)
    
    def upload_file(self):
        """Upload file attachment"""
        filetypes = [("All Files", "*.*")]
        filename = filedialog.askopenfilename(
            initialdir=os.getcwd(),
            title="Select File to Upload",
            filetypes=filetypes
        )
        if filename:
            # Copy file to upload directory
            import shutil
            try:
                dest_filename = os.path.join(self.upload_dir, os.path.basename(filename))
                shutil.copy2(filename, dest_filename)
                self.attach_listbox.insert(tk.END, dest_filename)
                self.append_output(f"Attachment uploaded: {os.path.basename(filename)}\n")
            except Exception as e:
                self.append_output(f"Error uploading file: {str(e)}\n")
    
    def remove_attachment(self):
        """Remove selected attachment"""
        selection = self.attach_listbox.curselection()
        if selection:
            index = selection[0]
            file_path = self.attach_listbox.get(index)
            try:
                if os.path.exists(file_path):
                    os.remove(file_path)
                self.attach_listbox.delete(index)
                self.append_output(f"Attachment removed: {os.path.basename(file_path)}\n")
            except Exception as e:
                self.append_output(f"Error removing file: {str(e)}\n")
    
    def clear_attachments(self):
        """Clear all attachments"""
        for i in range(self.attach_listbox.size()):
            file_path = self.attach_listbox.get(i)
            try:
                if os.path.exists(file_path):
                    os.remove(file_path)
            except Exception as e:
                self.append_output(f"Error removing file {file_path}: {str(e)}\n")
        self.attach_listbox.delete(0, tk.END)
        self.append_output("All attachments cleared\n")
    
    def detect_script_parameters(self):
        """Detect script parameters automatically"""
        script_path = self.script_path_var.get()
        if not script_path or not os.path.exists(script_path):
            return
        
        # Clear previous detected parameters
        for var, widget in self.param_widgets.values():
            widget.destroy()
        self.param_widgets.clear()
        self.detected_params.clear()
        
        # Detect parameters based on script type
        if script_path.endswith('.py'):
            self.detect_python_parameters(script_path)
        elif script_path.endswith('.sh'):
            self.detect_shell_parameters(script_path)
        
        # Update params entry if detected parameters
        if self.detected_params:
            params_str = ' '.join([f"--{k} {v}" for k, v in self.detected_params.items()])
            self.params_var.set(params_str)
    
    def detect_python_parameters(self, script_path):
        """Detect parameters for Python scripts"""
        try:
            # Read script content
            with open(script_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Look for argparse usage
            if 'argparse' in content:
                # Try to extract arguments using regex
                import re
                # Look for add_argument calls
                args = re.findall(r'add_argument\([\'\"]([^\"\']+)[\'\"]', content)
                if args:
                    row = 0
                    for arg in args:
                        # Remove leading dashes
                        arg_name = arg.lstrip('-')
                        # Create parameter widget
                        var = tk.StringVar(value="")
                        ttk.Label(self.params_content_frame, text=f"--{arg}:").grid(row=row, column=0, sticky=tk.W, pady=5)
                        entry = ttk.Entry(self.params_content_frame, textvariable=var, width=40)
                        entry.grid(row=row, column=1, sticky=tk.W, pady=5, padx=5)
                        self.param_widgets[arg] = (var, entry)
                        row += 1
            
            # Look for sys.argv usage (positional arguments)
            if 'sys.argv' in content:
                # Try to detect number of required arguments
                import re
                # Look for len(sys.argv) checks - handle both < and != cases
                len_checks = re.findall(r'len\(sys\.argv\)\s*([<>=!]+)\s*(\d+)', content)
                if len_checks:
                    # Get the first match
                    operator, num_str = len_checks[0]
                    required_args = int(num_str) - 1  # Subtract 1 for the script itself
                    
                    if required_args > 0:
                        row = 0
                        for i in range(1, required_args + 1):
                            var = tk.StringVar(value="")
                            ttk.Label(self.params_content_frame, text=f"Arg {i}:").grid(row=row, column=0, sticky=tk.W, pady=5)
                            entry = ttk.Entry(self.params_content_frame, textvariable=var, width=40)
                            entry.grid(row=row, column=1, sticky=tk.W, pady=5, padx=5)
                            self.param_widgets[f"positional_{i}"] = (var, entry)
                            row += 1
                        
                        # If there are attachments, suggest using them as arguments
                        if self.attach_listbox.size() > 0:
                            for i in range(min(required_args, self.attach_listbox.size())):
                                attachment_path = self.attach_listbox.get(i)
                                if f"positional_{i+1}" in self.param_widgets:
                                    var, _ = self.param_widgets[f"positional_{i+1}"]
                                    var.set(attachment_path)
                        
                        # For output arguments, suggest a default name
                        if required_args > self.attach_listbox.size():
                            for i in range(self.attach_listbox.size() + 1, required_args + 1):
                                if f"positional_{i}" in self.param_widgets:
                                    var, _ = self.param_widgets[f"positional_{i}"]
                                    # Suggest output file name based on input
                                    if self.attach_listbox.size() > 0:
                                        input_path = self.attach_listbox.get(0)
                                        base_name = os.path.splitext(os.path.basename(input_path))[0]
                                        output_name = f"{base_name}_output{os.path.splitext(input_path)[1]}"
                                        var.set(output_name)
                                    else:
                                        var.set(f"output_{i}.txt")
        
        except Exception as e:
            self.append_output(f"Error detecting parameters: {str(e)}\n")
    
    def detect_shell_parameters(self, script_path):
        """Detect parameters for shell scripts"""
        try:
            # Read script content
            with open(script_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Look for getopts usage
            if 'getopts' in content:
                # Try to extract options
                import re
                opts = re.findall(r'getopts\s+([a-zA-Z]+)', content)
                if opts:
                    row = 0
                    for opt_string in opts:
                        for opt in opt_string:
                            var = tk.StringVar(value="")
                            ttk.Label(self.params_content_frame, text=f"-{opt}:").grid(row=row, column=0, sticky=tk.W, pady=5)
                            entry = ttk.Entry(self.params_content_frame, textvariable=var, width=40)
                            entry.grid(row=row, column=1, sticky=tk.W, pady=5, padx=5)
                            self.param_widgets[f"-{opt}"] = (var, entry)
                            row += 1
        
        except Exception as e:
            self.append_output(f"Error detecting parameters: {str(e)}\n")
    
    def collect_detected_parameters(self):
        """Collect parameters from detected parameter widgets"""
        params = []
        # Collect positional arguments first
        positional_args = []
        for i in range(1, 10):  # Max 9 positional arguments
            key = f"positional_{i}"
            if key in self.param_widgets:
                var, _ = self.param_widgets[key]
                value = var.get().strip()
                if value:
                    positional_args.append(value)
        
        # Add positional arguments
        params.extend(positional_args)
        
        # Collect named arguments
        for arg, (var, _) in self.param_widgets.items():
            if not arg.startswith('positional_'):
                value = var.get().strip()
                if value:
                    params.append(f"{arg}")
                    params.append(f"{value}")
        
        return params
    
    def run_script(self):
        """Run script"""
        script_path = self.script_path_var.get()
        if not script_path:
            self.append_output("Error: Please select script file\n")
            return
        
        if not os.path.exists(script_path):
            self.append_output(f"Error: Script file does not exist: {script_path}\n")
            return
        
        # Prepare command
        cmd = [sys.executable, script_path] if script_path.endswith('.py') else [script_path]
        
        # Add parameters from detected widgets
        detected_params = self.collect_detected_parameters()
        if detected_params:
            cmd.extend(detected_params)
        
        # Add additional parameters
        params = self.params_var.get().strip()
        if params:
            # Split carefully to handle file paths with spaces
            import shlex
            try:
                cmd.extend(shlex.split(params))
            except:
                # Fallback to simple split if shlex fails
                cmd.extend(params.split())
        
        # Get working directory
        workdir = self.workdir_var.get()
        if not os.path.exists(workdir):
            self.append_output(f"Error: Working directory does not exist: {workdir}\n")
            return
        
        # Update script list
        self.update_script_list(script_path)
        
        # Save config
        self.save_config()
        
        # Show run information
        self.append_output(f"Running: {' '.join(cmd)}\n")
        self.append_output(f"Work Dir: {workdir}\n")
        self.append_output(f"Attachments: {self.attach_listbox.size()}\n")
        self.append_output("-" * 50 + "\n")
        
        # Disable run button, enable stop button
        self.run_button.config(state=tk.DISABLED)
        self.stop_button.config(state=tk.NORMAL)
        
        # Run script
        try:
            self.process = subprocess.Popen(
                cmd,
                cwd=workdir,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                universal_newlines=True
            )
            
            # Read output
            while self.process.poll() is None:
                line = self.process.stdout.readline()
                if line:
                    self.append_output(line)
                    self.root.update()
            
            # Read remaining output
            for line in self.process.stdout:
                self.append_output(line)
            
            # Show exit status
            exit_code = self.process.returncode
            if exit_code == 0:
                self.append_output(f"\nScript completed (Exit code: {exit_code})\n")
            else:
                self.append_output(f"\nScript failed (Exit code: {exit_code})\n")
                
        except Exception as e:
            self.append_output(f"Error: {str(e)}\n")
        finally:
            # Restore button state
            self.run_button.config(state=tk.NORMAL)
            self.stop_button.config(state=tk.DISABLED)
            self.process = None
    
    def stop_script(self):
        """Stop script"""
        if self.process:
            try:
                self.process.terminate()
                self.append_output("Script stopped\n")
            except Exception as e:
                self.append_output(f"Error stopping script: {str(e)}\n")
            finally:
                self.run_button.config(state=tk.NORMAL)
                self.stop_button.config(state=tk.DISABLED)
                self.process = None
    
    def clear_output(self):
        """Clear output"""
        self.output_text.delete(1.0, tk.END)
    
    def append_output(self, text):
        """Append output"""
        self.output_text.insert(tk.END, text)
        self.output_text.see(tk.END)
    
    def save_config(self):
        """Save configuration"""
        config = {
            "script_path": self.script_path_var.get(),
            "params": self.params_var.get(),
            "workdir": self.workdir_var.get(),
            "recent_scripts": [],
            "attachments": []
        }
        
        # Save recent scripts
        for i in range(self.script_listbox.size()):
            config["recent_scripts"].append(self.script_listbox.get(i))
        
        # Save attachments
        for i in range(self.attach_listbox.size()):
            config["attachments"].append(self.attach_listbox.get(i))
        
        try:
            with open(self.config_file, "w") as f:
                json.dump(config, f, indent=2)
            self.append_output(f"Config saved to: {self.config_file}\n")
        except Exception as e:
            self.append_output(f"Failed to save config: {str(e)}\n")
    
    def load_config(self):
        """Load configuration"""
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, "r") as f:
                    config = json.load(f)
                
                # Restore config
                if "script_path" in config:
                    self.script_path_var.set(config["script_path"])
                
                if "params" in config:
                    self.params_var.set(config["params"])
                
                if "workdir" in config:
                    self.workdir_var.set(config["workdir"])
                
                if "recent_scripts" in config:
                    # Clear list
                    self.script_listbox.delete(0, tk.END)
                    # Add scripts
                    for script in config["recent_scripts"]:
                        self.script_listbox.insert(tk.END, script)
                
                if "attachments" in config:
                    # Clear list
                    self.attach_listbox.delete(0, tk.END)
                    # Add attachments
                    for attachment in config["attachments"]:
                        if os.path.exists(attachment):
                            self.attach_listbox.insert(tk.END, attachment)
                
                # Detect parameters for loaded script
                if "script_path" in config and config["script_path"]:
                    self.detect_script_parameters()
                
            except Exception as e:
                self.append_output(f"Failed to load config: {str(e)}\n")
    
    def on_closing(self):
        """When window closing"""
        self.save_config()
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = ScriptUI(root)
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    root.mainloop()