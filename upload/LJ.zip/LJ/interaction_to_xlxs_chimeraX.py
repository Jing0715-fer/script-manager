# interaction_matrix_chimerax_final_v5.py
from chimerax.core.commands import run
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.utils import get_column_letter
import re

# ----------------------------
# 用户可变参数
# ----------------------------
chain_A = "#2/A"          # 分析链A
chains_BC = "#2/B-C"      # 分析链B和C
file_name = "D:/script/interaction_matrix_chimerax.xlsx"

# ----------------------------
# 删除所有 pseudobonds
# ----------------------------
run(session, "delete pseudobonds")

# ----------------------------
# STEP1: contacts
# ----------------------------
run(session, f'contacts {chain_A} restrict {chains_BC} reveal true log true namingStyle residue')
contacts_list = []
A_residues = set()
BC_residues = set()
for m in session.models:
    for pb in getattr(m, 'pseudobonds', []):
        if not pb.display:
            continue
        atoms = pb.atoms
        r1 = atoms[0].residue
        r2 = atoms[1].residue
        r1_full = f"{r1.name}{r1.number}({r1.chain_id})"
        r2_full = f"{r2.name}{r2.number}({r2.chain_id})"
        contacts_list.append((r1_full, r2_full))
        if r1.chain_id == chain_A[-1]:
            A_residues.add(r1_full)
        else:
            BC_residues.add(r1_full)
        if r2.chain_id == chain_A[-1]:
            A_residues.add(r2_full)
        else:
            BC_residues.add(r2_full)

# 删除 pseudobonds
run(session, "delete pseudobonds")

# ----------------------------
# STEP2: hydrogen bonds
# ----------------------------
run(session, f'hbonds {chain_A} restrict {chains_BC} reveal true log true namingStyle residue')
hbonds_list = []
for m in session.models:
    for pb in getattr(m, 'pseudobonds', []):
        if not pb.display:
            continue
        atoms = pb.atoms
        r1 = atoms[0].residue
        r2 = atoms[1].residue
        r1_full = f"{r1.name}{r1.number}({r1.chain_id})"
        r2_full = f"{r2.name}{r2.number}({r2.chain_id})"
        hbonds_list.append((r1_full, r2_full))
        if r1.chain_id == chain_A[-1]:
            A_residues.add(r1_full)
        else:
            BC_residues.add(r1_full)
        if r2.chain_id == chain_A[-1]:
            A_residues.add(r2_full)
        else:
            BC_residues.add(r2_full)

# 删除 pseudobonds
run(session, "delete pseudobonds")

# ----------------------------
# STEP3: salt bridges
# ----------------------------
run(session, f'hbonds {chain_A} restrict {chains_BC} saltOnly true reveal true log true namingStyle residue')
salt_list = []
for m in session.models:
    for pb in getattr(m, 'pseudobonds', []):
        if not pb.display:
            continue
        atoms = pb.atoms
        r1 = atoms[0].residue
        r2 = atoms[1].residue
        r1_full = f"{r1.name}{r1.number}({r1.chain_id})"
        r2_full = f"{r2.name}{r2.number}({r2.chain_id})"
        salt_list.append((r1_full, r2_full))
        if r1.chain_id == chain_A[-1]:
            A_residues.add(r1_full)
        else:
            BC_residues.add(r1_full)
        if r2.chain_id == chain_A[-1]:
            A_residues.add(r2_full)
        else:
            BC_residues.add(r2_full)

# ----------------------------
# 排序
# ----------------------------
def residue_sort_key(res):
    return int(re.search(r'\d+', res).group())

A_list = sorted(A_residues, key=residue_sort_key)
BC_list = sorted(BC_residues, key=lambda x: (x[-2], residue_sort_key(x)))

# ----------------------------
# 创建矩阵
# ----------------------------
contacts_matrix = pd.DataFrame(" ", index=A_list, columns=BC_list)
for r1, r2 in contacts_list:
    if r1 in contacts_matrix.index and r2 in contacts_matrix.columns:
        contacts_matrix.at[r1, r2] = "√"
    elif r2 in contacts_matrix.index and r1 in contacts_matrix.columns:
        contacts_matrix.at[r2, r1] = "√"

hbonds_matrix = pd.DataFrame(" ", index=A_list, columns=BC_list)
for r1, r2 in hbonds_list:
    if r1 in hbonds_matrix.index and r2 in hbonds_matrix.columns:
        hbonds_matrix.at[r1, r2] = "H"
    elif r2 in hbonds_matrix.index and r1 in hbonds_matrix.columns:
        hbonds_matrix.at[r2, r1] = "H"

salt_matrix = pd.DataFrame(" ", index=A_list, columns=BC_list)
for r1, r2 in salt_list:
    if r1 in salt_matrix.index and r2 in salt_matrix.columns:
        salt_matrix.at[r1, r2] = "S"
    elif r2 in salt_matrix.index and r1 in salt_matrix.columns:
        salt_matrix.at[r2, r1] = "S"

# 合并矩阵，优先级 S > H > √
final_matrix = contacts_matrix.copy()
for r in final_matrix.index:
    for c in final_matrix.columns:
        if salt_matrix.at[r, c] == "S":
            final_matrix.at[r, c] = "S"
        elif hbonds_matrix.at[r, c] == "H":
            final_matrix.at[r, c] = "H"

# ----------------------------
# 保存 Excel 并美化
# ----------------------------
with pd.ExcelWriter(file_name, engine='openpyxl') as writer:
    pd.DataFrame([["Critical residues in epitope"] + [""]*(len(final_matrix.columns)-1)]).to_excel(writer, index=False, header=False)
    final_matrix.to_excel(writer, startrow=1, index_label="")

wb = load_workbook(file_name)
ws = wb.active

# 合并标题
ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ws.max_column)
ws['A1'].font = Font(size=14, bold=True)
ws['A1'].alignment = Alignment(horizontal='center')

# 添加说明行
note_row = ws.max_row + 2
ws.merge_cells(start_row=note_row, start_column=1, end_row=note_row, end_column=ws.max_column)
ws.cell(row=note_row, column=1).value = "Note: √ = contact interaction; H = hydrogen bond; S = salt bridge."
ws.cell(row=note_row, column=1).alignment = Alignment(horizontal='left')

# 自动列宽 (第二行到倒数第二行)
for col in ws.iter_cols(min_row=2, max_row=ws.max_row-2):
    max_length = 0
    col_letter = get_column_letter(col[0].column)
    for cell in col:
        if cell.value:
            max_length = max(max_length, len(str(cell.value)))
    ws.column_dimensions[col_letter].width = max_length + 2

# ----------------------------
# 添加颜色标注
# ----------------------------
color_map = {"√": "BDD7EE", "H": "FFC7CE", "S": "C6EFCE"}  # 蓝, 红, 绿
for row in ws.iter_rows(min_row=2, max_row=ws.max_row-2):
    for cell in row[1:]:  # 跳过第一列（A链残基）
        if cell.value in color_map:
            cell.fill = PatternFill(start_color=color_map[cell.value], end_color=color_map[cell.value], fill_type="solid")

wb.save(file_name)
print(f"Excel 文件已生成：{file_name}（√=蓝，H=红，S=绿）")
