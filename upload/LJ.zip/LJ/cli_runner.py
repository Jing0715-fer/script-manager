#!/usr/bin/env python3

import os
import sys
import subprocess
import json
import glob

class CLIRunner:
    def __init__(self):
        """Initialize CLI runner"""
        self.script_dir = os.path.dirname(os.path.abspath(__file__))
        self.upload_dir = os.path.join(self.script_dir, "uploads")
        if not os.path.exists(self.upload_dir):
            os.makedirs(self.upload_dir)
        self.config_file = "cli_runner_config.json"
        
    def list_scripts(self):
        """List available scripts"""
        print("Available scripts:")
        print("-" * 50)
        
        # Find Python scripts
        scripts = []
        for root, dirs, files in os.walk(self.script_dir):
            # Skip __pycache__ and uploads directories
            dirs[:] = [d for d in dirs if d not in ['__pycache__', 'uploads']]
            
            for file in files:
                if file.endswith('.py') and file not in ['cli_runner.py', 'script_ui.py', 'script_runner.py']:
                    script_path = os.path.join(root, file)
                    scripts.append(script_path)
        
        # Sort scripts by name
        scripts.sort(key=lambda x: os.path.basename(x))
        
        # Display scripts
        for i, script in enumerate(scripts, 1):
            rel_path = os.path.relpath(script, self.script_dir)
            print(f"{i}. {rel_path}")
        
        print("-" * 50)
        return scripts
    
    def list_attachments(self):
        """List available attachments"""
        attachments = []
        if os.path.exists(self.upload_dir):
            for file in os.listdir(self.upload_dir):
                if os.path.isfile(os.path.join(self.upload_dir, file)):
                    attachments.append(os.path.join(self.upload_dir, file))
        
        if attachments:
            print("Available attachments:")
            print("-" * 50)
            for i, attachment in enumerate(attachments, 1):
                rel_path = os.path.relpath(attachment, self.script_dir)
                print(f"{i}. {rel_path}")
            print("-" * 50)
        else:
            print("No attachments available.")
        
        return attachments
    
    def detect_script_parameters(self, script_path):
        """Detect script parameters"""
        parameters = []
        
        try:
            with open(script_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Look for sys.argv usage
            if 'sys.argv' in content:
                import re
                # Look for len(sys.argv) checks
                len_checks = re.findall(r'len\(sys\.argv\)\s*([<>=!]+)\s*(\d+)', content)
                if len_checks:
                    operator, num_str = len_checks[0]
                    required_args = int(num_str) - 1
                    if required_args > 0:
                        parameters.extend([f"Arg {i}" for i in range(1, required_args + 1)])
            
            # Look for argparse usage
            if 'argparse' in content:
                import re
                args = re.findall(r'add_argument\([\'\"]([^\"\']+)[\'\"]', content)
                if args:
                    parameters.extend([f"--{arg}" for arg in args])
        
        except Exception as e:
            print(f"Error detecting parameters: {e}")
        
        return parameters
    
    def run_script(self, script_path, params=None):
        """Run script with parameters"""
        if not os.path.exists(script_path):
            print(f"Error: Script {script_path} does not exist.")
            return
        
        # Prepare command
        cmd = [sys.executable, script_path]
        
        # Add parameters
        if params:
            cmd.extend(params)
        
        print(f"\nRunning: {' '.join(cmd)}")
        print(f"Work directory: {self.script_dir}")
        print("-" * 50)
        
        # Run script
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                cwd=self.script_dir
            )
            
            # Print output
            if result.stdout:
                print("Output:")
                print(result.stdout)
            
            # Print errors
            if result.stderr:
                print("Errors:")
                print(result.stderr)
            
            print(f"\nExit code: {result.returncode}")
            if result.returncode == 0:
                print("Script completed successfully!")
            else:
                print("Script failed.")
                
        except Exception as e:
            print(f"Error running script: {e}")
    
    def main(self):
        """Main function"""
        print("Script Runner CLI")
        print("=" * 50)
        
        # List scripts
        scripts = self.list_scripts()
        
        if not scripts:
            print("No scripts found.")
            return
        
        # Select script
        while True:
            try:
                choice = int(input("\nEnter script number to run (0 to exit): "))
                if choice == 0:
                    print("Exiting...")
                    return
                elif 1 <= choice <= len(scripts):
                    selected_script = scripts[choice - 1]
                    break
                else:
                    print("Invalid choice. Please try again.")
            except ValueError:
                print("Please enter a number.")
        
        print(f"\nSelected script: {os.path.basename(selected_script)}")
        
        # Detect parameters
        parameters = self.detect_script_parameters(selected_script)
        
        # List attachments
        attachments = self.list_attachments()
        
        # Get parameters from user
        user_params = []
        
        if parameters:
            print("\nParameters:")
            print("-" * 50)
            
            for param in parameters:
                if param.startswith('Arg'):
                    # For positional arguments, suggest attachments
                    if attachments:
                        print(f"\nAvailable attachments for {param}:")
                        for i, att in enumerate(attachments, 1):
                            print(f"  {i}. {os.path.basename(att)}")
                        print("  0. Enter custom value")
                        
                        try:
                            att_choice = int(input(f"Select attachment for {param} (0 for custom): "))
                            if att_choice == 0:
                                value = input(f"Enter value for {param}: ")
                            elif 1 <= att_choice <= len(attachments):
                                value = attachments[att_choice - 1]
                            else:
                                value = input(f"Enter value for {param}: ")
                        except ValueError:
                            value = input(f"Enter value for {param}: ")
                    else:
                        value = input(f"Enter value for {param}: ")
                    user_params.append(value)
                else:
                    # For named arguments
                    value = input(f"Enter value for {param}: ")
                    user_params.extend([param, value])
        
        # Run script
        self.run_script(selected_script, user_params)
        
        # Ask to run another script
        while True:
            again = input("\nRun another script? (y/n): ").lower()
            if again == 'y':
                self.main()
                return
            elif again == 'n':
                print("Exiting...")
                return
            else:
                print("Please enter 'y' or 'n'.")

if __name__ == "__main__":
    runner = CLIRunner()
    runner.main()