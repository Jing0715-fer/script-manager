import re
import sys
from collections import defaultdict

def split_star_by_date(input_star, output_prefix):
    # 读取文件内容
    with open(input_star, 'r') as f:
        content = f.readlines()
    
    # 分离光学信息和粒子信息
    optics_section = []
    particles_section = []
    current_section = None
    
    for line in content:
        if line.startswith('data_optics'):
            current_section = 'optics'
            optics_section.append(line)
        elif line.startswith('data_particles'):
            current_section = 'particles'
            particles_section.append(line)
        else:
            if current_section == 'optics':
                optics_section.append(line)
            elif current_section == 'particles':
                particles_section.append(line)
    
    # 解析粒子部分，按日期分组
    date_particles = defaultdict(list)
    header = []
    in_header = True
    data_started = False
    
    for line in particles_section:
        # 将所有行添加到header，直到我们找到第一个数据行
        if not data_started:
            header.append(line)
            # 检查是否已经到达数据部分
            if not line.startswith('_rln') and not line.startswith('loop_') and line.strip() and not line.startswith('data_'):
                data_started = True
            continue
        
        # 分割行并检查是否有足够的元素
        parts = line.split()
        if len(parts) < 10:  # 根据您的数据，应该有至少10列
            print(f"警告: 跳过格式不正确的行: {line}")
            continue
            
        # 从micrograph名称中提取第二个日期
        micrograph_name = parts[1]
        
        # 提取第二个日期（时间戳前面的日期）
        date_match = re.search(r'_(\d{8})_\d{6}', micrograph_name)
        
        if date_match:
            date = date_match.group(1)
            date_particles[date].append(line)
        else:
            # 如果没有找到日期，放入unknown组
            date_particles['unknown'].append(line)
            print(f"警告: 无法从micrograph名称中提取日期: {micrograph_name}")
    
    # 打印找到的日期
    print(f"找到的日期: {list(date_particles.keys())}")
    
    # 为每个日期创建新的star文件
    for date, particles in date_particles.items():
        output_filename = f"{output_prefix}_{date}.star"
        
        with open(output_filename, 'w') as f:
            # 写入光学信息部分
            f.writelines(optics_section)
            
            # 确保光学部分和粒子部分之间有适当的空行
            if optics_section and optics_section[-1].strip():
                f.write('\n')
            
            # 写入粒子信息部分
            f.writelines(header)
            f.writelines(particles)
    
    print(f"成功拆分文件，共找到 {len(date_particles)} 个不同的日期")
    print(f"每个日期的粒子数量:")
    for date, particles in date_particles.items():
        print(f"  {date}: {len(particles)} 个粒子")

# 使用命令行参数
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("使用方法: python split_star.py <输入文件> [输出前缀]")
        print("示例: python split_star.py particles.star split")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_prefix = sys.argv[2] if len(sys.argv) > 2 else "split"
    
    split_star_by_date(input_file, output_prefix)