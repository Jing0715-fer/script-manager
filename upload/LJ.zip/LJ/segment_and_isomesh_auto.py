from pymol import cmd, util
import random

def resi_to_int(resi):
    try:
        return int(''.join(filter(str.isdigit, str(resi))))
    except:
        return 0

def segment_and_show(pdb_obj, map_obj=None, base_isovalue=0.8, base_radius=2.0,
                     keep_only_segments=False, hide_loop=False, single_color=None,
                     override_level=None, override_carve=None):
    """
    分段显示 stick + mesh，每段独立 scene，O/N/S/C 默认元素颜色
    打印 isomesh 命令便于调整
    """

    # ---------------------------
    # 清理旧 scene
    # ---------------------------
    for sc in cmd.get_scene_list():
        cmd.scene(sc, "delete")

    # ---------------------------
    # 全局设定
    # ---------------------------
    cmd.bg_color("white")
    cmd.set("mesh_width", 0.5)
    cmd.set("mesh_color", "density")
    cmd.set("ray_shadow", 0)
    cmd.set("valence", 0)

    # Stick 显示 PDB
    cmd.show("sticks", pdb_obj)
    util.cnc(pdb_obj)  # 强制 color by element
    cmd.hide("cartoon", pdb_obj)

    # DSS 分析二级结构
    cmd.dss(pdb_obj)
    model = cmd.get_model(pdb_obj)

    residues = []
    seen = set()
    for a in model.atom:
        key = (a.chain, a.resi, a.resn)
        if key in seen:
            continue
        seen.add(key)
        ss = getattr(a, 'ss', '') or ''
        if ss.upper().startswith('H'):
            sstype = 'H'
        elif ss.upper().startswith(('S','E')):
            sstype = 'S'
        else:
            sstype = 'L'
        residues.append({'chain': a.chain or '', 'resi': a.resi, 'resn': a.resn, 'ss': sstype})

    if not residues:
        print("未检测到残基，请确认对象正确。")
        return

    # 按二级结构分段
    segments = []
    idx, i, N = 0, 0, len(residues)
    while i < N:
        cur = residues[i]
        chain, cur_ss = cur['chain'], cur['ss']
        start_resi = cur['resi']
        i += 1
        while i < N and residues[i]['chain']==chain and residues[i]['ss']==cur_ss:
            i += 1
        end_resi = residues[i-1]['resi']
        idx += 1
        segments.append({'id': idx, 'chain': chain, 'ss': cur_ss,
                         'start_resi': start_resi, 'end_resi': end_resi})

    def random_color_hex():
        return "#{:06x}".format(random.randint(0,0xFFFFFF))

    seg_objs = []
    mesh_objs = []

    scene_counter = 1
    for seg in segments:
        if hide_loop and seg['ss'] == 'L':
            continue

        start = resi_to_int(seg['start_resi'])
        end = resi_to_int(seg['end_resi'])
        res_count = max(1, end-start+1)

        sele = f"({pdb_obj} and chain {seg['chain']} and resi {seg['start_resi']}-{seg['end_resi']})" if seg['chain'] else f"({pdb_obj} and resi {seg['start_resi']}-{seg['end_resi']})"
        obj_name = f"{pdb_obj}_seg_{seg['id']}"
        cmd.delete(obj_name)
        cmd.create(obj_name, sele)
        seg_objs.append(obj_name)

        # ---------------------------
        # 颜色
        # ---------------------------
        if single_color:
            color_name = single_color
        else:
            color_hex = random_color_hex()
            rgb = tuple(int(color_hex[i:i+2],16)/255.0 for i in (1,3,5))
            color_name = f"col_seg_{seg['id']}"
            cmd.set_color(color_name, rgb)

        cmd.show("sticks", obj_name)
        util.cnc(obj_name)  # 强制 color by element

        # ---------------------------
        # mesh
        # ---------------------------
        mesh_name = None
        if map_obj:
            mesh_name = f"map_seg_{seg['id']}"
            cmd.delete(mesh_name)

            radius_val = max(base_radius, res_count/5.0)
            carve_val = override_carve if override_carve else min(max(1.5, res_count*0.3), 4.0)
            level_val = override_level if override_level else (base_isovalue*0.8 if res_count<10 else base_isovalue*0.9 if res_count<20 else base_isovalue)

            print(f'cmd.isomesh("{mesh_name}", "{map_obj}", {level_val:.2f}, "{sele}", {radius_val:.1f}, 0, {carve_val:.1f})')

            cmd.isomesh(mesh_name, map_obj, level_val, sele, radius_val, 0, carve_val)
            cmd.color(color_name, mesh_name)
            cmd.set("transparency", 0.5, mesh_name)
            mesh_objs.append(mesh_name)

        # ---------------------------
        # 每段独立 scene
        # ---------------------------
        # 先隐藏所有 segment 和 mesh
        for o in seg_objs:
            cmd.disable(o)
        for m in mesh_objs:
            cmd.disable(m)
        cmd.disable(pdb_obj)

        # 显示当前 segment
        cmd.enable(obj_name)
        if mesh_name:
            cmd.enable(mesh_name)

        # 居中 + 创建 scene
        cmd.zoom(obj_name, buffer=5)
        scene_name = f"seg_{scene_counter:03d}"
        cmd.scene(scene_name, "store")
        scene_counter += 1

        print(f"Segment {seg['id']:3d}: chain {seg['chain'] or '-'} {seg['start_resi']}-{seg['end_resi']} ({seg['ss']}), scene={scene_name}")

    # ---------------------------
    # 回到 scene_001
    # ---------------------------
    if scene_counter > 1:
        cmd.scene("seg_001", "recall")

    print(f"\n分段完成，共 {scene_counter-1} 段，每段已创建独立 scene。")

def segment_and_show_auto(base_isovalue=0.8, base_radius=2.0, keep_only_segments=False,
                          map_obj=None, hide_loop=False, single_color=None,
                          override_level=None, override_carve=None):
    objs = cmd.get_object_list()
    if len(objs)==0:
        raise Exception("⚠️ 没有加载任何对象！请先 load pdb")
    struct_obj = objs[0]
    print(f"✅ 使用结构对象: {struct_obj}")
    if map_obj:
        print(f"✅ 使用密度图对象: {map_obj}")
    else:
        print("⚠️ 未指定密度图，将只显示结构。")
    segment_and_show(struct_obj, map_obj, base_isovalue, base_radius, keep_only_segments,
                     hide_loop, single_color, override_level, override_carve)

# 注册 PyMOL 命令
cmd.extend('segment_and_show_auto',
           lambda base_isovalue='0.8', base_radius='2.0', keep_only_segments='0',
                  map_obj=None, hide_loop='0', single_color=None,
                  override_level=None, override_carve=None:
               segment_and_show_auto(
                   base_isovalue=float(base_isovalue),
                   base_radius=float(base_radius),
                   keep_only_segments=bool(int(keep_only_segments)),
                   map_obj=map_obj,
                   hide_loop=bool(int(hide_loop)),
                   single_color=single_color,
                   override_level=float(override_level) if override_level else None,
                   override_carve=float(override_carve) if override_carve else None
               ))

#用法segment_and_show_auto 0.8, 2.0, 1, map_obj="M1R+B36B9-Fab_DeepEMhancer", hide_loop=1, single_color="green", override_level=0.9, override_carve=2.5

