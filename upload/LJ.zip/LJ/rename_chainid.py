import argparse
from Bio.PDB import PDBParser, PDBIO
import numpy as np
import string

def chain_center(chain):
    coords = [atom.coord for atom in chain.get_atoms()]
    return np.mean(coords, axis=0)

def reorder_fiber_chains_ccw(pdb_file, out_file, n_per_layer=4, axis_layer="z"):
    parser = PDBParser(QUIET=True)
    structure = parser.get_structure("struct", pdb_file)

    chains = []
    centers = []

    for model in structure:
        for chain in model:
            chains.append(chain)
            centers.append(chain_center(chain))

    centers = np.array(centers)
    axis_index = {"x": 0, "y": 1, "z": 2}

    # 按层方向排序（默认 z）
    layer_sorted = sorted(
        zip(chains, centers),
        key=lambda x: x[1][axis_index[axis_layer]]
    )

    # 分层
    grouped = [layer_sorted[i:i+n_per_layer] for i in range(0, len(layer_sorted), n_per_layer)]

    final_order = []
    for group in grouped:
        group_chains, group_centers = zip(*group)
        group_centers = np.array(group_centers)

        # 计算层中心
        layer_center = np.mean(group_centers, axis=0)

        # 计算每个链的角度（逆时针）
        angles = np.arctan2(group_centers[:,1] - layer_center[1],
                            group_centers[:,0] - layer_center[0])

        # 按角度排序 (逆时针)
        idx_sorted = np.argsort(angles)
        for idx in idx_sorted:
            final_order.append(group_chains[idx])

    # 重新编号
    letters = list(string.ascii_uppercase)
    for i, chain in enumerate(final_order):
        if i < len(letters):
            chain.id = letters[i]
        else:
            chain.id = str(i)

    io = PDBIO()
    io.set_structure(structure)
    io.save(out_file)
    print(f"✅ Saved reordered PDB to {out_file}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Reorder fiber-like PDB chains by layer and counter-clockwise order within layer.")
    parser.add_argument("-i", "--input", required=True, help="输入 PDB 文件")
    parser.add_argument("-o", "--output", required=True, help="输出 PDB 文件")
    parser.add_argument("-n", "--n_per_layer", type=int, default=4, help="每层链数量 (默认: 4)")
    parser.add_argument("--axis_layer", choices=["x","y","z"], default="z", help="分层方向 (默认: z)")
    args = parser.parse_args()

    reorder_fiber_chains_ccw(args.input, args.output, n_per_layer=args.n_per_layer, axis_layer=args.axis_layer)
