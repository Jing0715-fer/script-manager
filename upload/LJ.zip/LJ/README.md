# 脚本运行器使用说明

## 项目简介

本项目提供了两个脚本运行器UI界面，帮助用户更方便地运行和管理终端脚本：

1. **script_ui.py** - 基于Tkinter的简单界面
2. **script_runner.py** - 基于PyQt5的专业界面

## 功能特点

### 通用功能
- 脚本文件浏览和选择
- 最近使用脚本管理
- 参数输入和配置
- 工作目录设置
- 实时运行输出显示
- 脚本运行控制（启动/停止）
- 配置自动保存和加载

### script_runner.py 额外功能
- 现代美观的界面
- 输出时间戳显示
- 脚本模板管理
- 更详细的错误处理
- 可定制的缓冲区大小

## 环境要求

### 基础要求
- Python 3.6+

### script_ui.py 依赖
- 标准库：tkinter（Python内置）

### script_runner.py 依赖
- PyQt5：`pip install PyQt5`

## 使用方法

### 方法一：使用 script_ui.py（简单）
1. 运行脚本：
   ```bash
   python script_ui.py
   ```
2. 在界面中：
   - 点击"浏览"按钮选择脚本文件
   - 输入脚本参数
   - 选择工作目录
   - 点击"运行脚本"按钮执行

### 方法二：使用 script_runner.py（专业）
1. 安装依赖：
   ```bash
   pip install PyQt5
   ```
2. 运行脚本：
   ```bash
   python script_runner.py
   ```
3. 在界面中：
   - 在"脚本选择"标签页选择脚本
   - 在"参数设置"标签页配置参数
   - 点击"运行脚本"按钮执行
   - 在"配置"标签页自定义设置

## 针对 ChimeraX 脚本的使用说明

本目录中的脚本大多是 ChimeraX 插件脚本，如：
- `auto_color_locres.py` - 自动为EM map着色
- `pi.py` - π-π堆积相互作用分析
- `rmsd.py` - RMSD计算
- `find_cdr_of_fab.py` - 查找FAB的CDR区域

### 运行 ChimeraX 脚本的方法

#### 方法一：在 ChimeraX 中直接运行
1. 启动 ChimeraX
2. 在命令行中输入：
   ```
   open /path/to/script.py
   ```
3. 按照脚本说明使用相应命令

#### 方法二：使用脚本运行器
1. 打开脚本运行器
2. 选择 ChimeraX 可执行文件作为脚本（如果需要）
3. 在参数中指定要运行的Python脚本
4. 点击"运行"按钮

## 配置文件

脚本运行器会自动创建和管理配置文件：
- `script_ui_config.json` - script_ui.py 的配置
- `script_runner_config.json` - script_runner.py 的配置

配置文件会保存：
- 最近使用的脚本列表
- 工作目录设置
- 参数配置
- 界面偏好设置

## 常见问题解决

### 1. PyQt5 安装失败
- 尝试使用国内源：`pip install PyQt5 -i https://pypi.tuna.tsinghua.edu.cn/simple`
- 或使用 PyQt5 的 wheels 版本

### 2. 脚本运行无输出
- 检查脚本是否需要交互输入
- 确保脚本有输出语句
- 检查工作目录权限

### 3. 权限错误
- 在Linux/Mac上，确保脚本有执行权限：`chmod +x script.py`
- 在Windows上，以管理员身份运行

### 4. ChimeraX 脚本无法运行
- 确保 ChimeraX 已正确安装
- 检查脚本中的 `session` 变量是否正确处理
- 最好在 ChimeraX 内部运行这些脚本

## 示例使用场景

### 场景1：运行 auto_color_locres.py
1. 启动 ChimeraX
2. 打开EM map和locres map文件
3. 在命令行中输入：
   ```
   open /path/to/auto_color_locres.py
   ```
4. 脚本会自动为EM map着色

### 场景2：运行 pi.py 分析π-π相互作用
1. 启动 ChimeraX
2. 打开蛋白质结构文件
3. 在命令行中输入：
   ```
   open /path/to/pi.py
   ```
4. 使用命令分析：
   ```
   pi_pi distance 4.5 angle 30
   ```

## 自定义扩展

### 添加新的脚本模板
1. 编辑 `script_runner.py` 中的模板管理部分
2. 或在配置文件中手动添加模板

### 修改界面样式
1. 对于 `script_runner.py`，可以修改 Qt 样式表
2. 对于 `script_ui.py`，可以修改 Tkinter 主题

## 联系信息

如有问题或建议，请联系：
- 作者：LJ
- 邮箱：[your_email@example.com]
- 日期：2026-01-15