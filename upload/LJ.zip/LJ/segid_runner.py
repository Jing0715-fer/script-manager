#!/usr/bin/env python3

import os
import sys
import subprocess

class SegIDRunner:
    def __init__(self):
        """Initialize SegID runner"""
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.segid_path = "/mnt/d/script/segID.py"
        self.upload_dir = os.path.join(self.base_dir, "uploads")
        
        if not os.path.exists(self.upload_dir):
            os.makedirs(self.upload_dir)
    
    def check_segid(self):
        """Check if segID.py exists"""
        if not os.path.exists(self.segid_path):
            print(f"Error: segID.py not found at {self.segid_path}")
            return False
        return True
    
    def list_pdb_files(self):
        """List available PDB files"""
        pdb_files = []
        
        # Check current directory
        for file in os.listdir(self.base_dir):
            if file.endswith('.pdb'):
                pdb_files.append(os.path.join(self.base_dir, file))
        
        # Check uploads directory
        if os.path.exists(self.upload_dir):
            for file in os.listdir(self.upload_dir):
                if file.endswith('.pdb'):
                    pdb_files.append(os.path.join(self.upload_dir, file))
        
        if pdb_files:
            print("Available PDB files:")
            print("-" * 60)
            for i, pdb_file in enumerate(pdb_files, 1):
                size = os.path.getsize(pdb_file)
                rel_path = os.path.relpath(pdb_file, self.base_dir)
                print(f"{i:2d}. {rel_path} ({size:,} bytes)")
            print("-" * 60)
        else:
            print("No PDB files found in current directory or uploads/")
        
        return pdb_files
    
    def run_segid(self, input_pdb, output_pdb):
        """Run segID.py on the given PDB file"""
        if not self.check_segid():
            return
        
        if not os.path.exists(input_pdb):
            print(f"Error: Input PDB file not found: {input_pdb}")
            return
        
        print(f"\nRunning segID.py")
        print("-" * 60)
        print(f"Input:  {os.path.relpath(input_pdb, self.base_dir)}")
        print(f"Output: {os.path.relpath(output_pdb, self.base_dir)}")
        print("-" * 60)
        
        # Run segID.py
        try:
            cmd = [sys.executable, self.segid_path, input_pdb, output_pdb]
            
            result = subprocess.run(
                cmd,
                cwd=self.base_dir,
                capture_output=True,
                text=True
            )
            
            # Print output
            if result.stdout:
                print("Output:")
                print(result.stdout)
            
            # Print errors
            if result.stderr:
                print("Errors:")
                print(result.stderr)
            
            print("-" * 60)
            print(f"Exit code: {result.returncode}")
            
            if result.returncode == 0:
                print("✓ segID.py completed successfully!")
                print(f"Output file: {os.path.relpath(output_pdb, self.base_dir)}")
            else:
                print("✗ segID.py failed!")
                
        except Exception as e:
            print(f"✗ Error running segID.py: {e}")
    
    def main(self):
        """Main function"""
        print("segID.py Runner")
        print("=" * 60)
        print("A tool to run segID.py without GUI")
        print("=" * 60)
        
        if not self.check_segid():
            return
        
        # List PDB files
        pdb_files = self.list_pdb_files()
        
        # Get input file
        if pdb_files:
            while True:
                try:
                    choice = int(input("\nEnter PDB file number to process (0 to enter path): "))
                    if choice == 0:
                        input_pdb = input("Enter input PDB file path: ")
                        break
                    elif 1 <= choice <= len(pdb_files):
                        input_pdb = pdb_files[choice - 1]
                        break
                    else:
                        print(f"Please enter a number between 0 and {len(pdb_files)}")
                except ValueError:
                    print("Please enter a valid number")
        else:
            input_pdb = input("Enter input PDB file path: ")
        
        # Get output file
        if input_pdb:
            base_name = os.path.splitext(os.path.basename(input_pdb))[0]
            default_output = os.path.join(self.base_dir, f"{base_name}_clean.pdb")
            output_pdb = input(f"Enter output PDB file path [{os.path.basename(default_output)}]: ")
            
            if not output_pdb:
                output_pdb = default_output
        
        # Run segID.py
        if input_pdb and output_pdb:
            self.run_segid(input_pdb, output_pdb)

if __name__ == "__main__":
    runner = SegIDRunner()
    runner.main()