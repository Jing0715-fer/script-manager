# rmsd_cx_v6.py
# ChimeraX version of the PyMOL rmsd_multi_chain_heatmap_log script
# 修复了 ID 匹配逻辑：无论输入 '#1' 还是 '1'，只要 ID 对应，就能找到模型
from chimerax.core.commands import run
from chimerax.core.commands import CmdDesc, register
from chimerax.core.commands import StringArg
import numpy as np
import os

def get_model_from_string(session, ident_str):
    """
    增强型模型查找：支持 #1, 1, 以及模型名称
    """
    ident_str = ident_str.strip()
    candidates = []
    all_models = session.models.list()
    
    # 1. 预处理用户输入，提取核心 ID (例如 #1 -> 1)
    target_id_val = None
    target_name = ident_str
    
    if ident_str.startswith("#"):
        target_id_val = ident_str[1:] # 去掉 #
    elif ident_str.isdigit():
        target_id_val = ident_str
    
    # 2. 遍历查找
    for m in all_models:
        # 获取模型的 ID 字符串 (可能是 "1" 或 "#1")
        m_id_str = str(m.id_string)
        m_id_val = m_id_str # 假设就是字符串
        
        # 归一化处理：去掉 # 以便对比
        if m_id_str.startswith("#"):
            m_id_val = m_id_str[1:]
            
        # 逻辑 A: ID 匹配 (用户输入 #1 或 1，模型 ID 是 1 或 #1)
        if target_id_val is not None and m_id_val == target_id_val:
            candidates.append(m)
            
        # 逻辑 B: 名称匹配
        elif m.name == target_name or f"#{m.name}" == target_name:
            candidates.append(m)
            
    if len(candidates) == 1:
        return candidates[0]
    
    if len(candidates) > 1:
        session.logger.warning(f"找到多个匹配 '{ident_str}' 的模型，使用第一个: {candidates[0].name}")
        return candidates[0]
    
    # 3. 如果未找到，列出提示
    error_msg = f"\n错误: 未找到模型 '{ident_str}'。\n请尝试使用纯数字 ID (例如 1, 2)。\n当前可用模型:\n"
    for m in all_models:
        # 这里列出建议使用的命令参数
        if str(m.id_string).startswith("#"):
            suggestion = str(m.id_string) # 如果自带 #
        else:
            suggestion = f"#{m.id_string}" # 如果没有 #
        error_msg += f"  模型: {m.name} (可用ID: {suggestion})\n"
        
    raise ValueError(error_msg)

def rmsd_multi_chain_heatmap_log(session, target="#1", mobile="#2", selection="name CA", out_prefix="rmsd"):
    """
    Calculate multi-chain RMSD, match chains, color target by per-residue RMSD.
    """
    
    # ------------------------------
    # 1. 获取模型对象
    # ------------------------------
    try:
        m_target = get_model_from_string(session, target)
        m_mobile = get_model_from_string(session, mobile)
        session.logger.status(f"Target: {m_target.name} (ID: {m_target.id_string}), Mobile: {m_mobile.name} (ID: {m_mobile.id_string})")
    except ValueError as e:
        session.logger.error(str(e))
        return
    
    # 解析 selection 参数
    clean_sel = selection.replace("name ", "").replace("(", "").replace(")", "")
    clean_sel = clean_sel.replace("+", ",") 
    target_atom_names = set([x.strip() for x in clean_sel.split(",")])
    
    # ------------------------------
    # 2. 对齐
    # ------------------------------
    # 注意：这里运行 match 命令时，最好加上 # 符号以确保 ChimeraX 解析正确
    t_sel = m_target.id_string
    m_sel = m_mobile.id_string
    if not t_sel.startswith("#"): t_sel = "#" + t_sel
    if not m_sel.startswith("#"): m_sel = "#" + m_sel
    
    run(session, f"match {m_sel} to {t_sel}")
    
    # ------------------------------
    # 3. 可视化设置
    # ------------------------------
    run(session, "bg color white")
    run(session, "hide") 
    run(session, f"show cartoon {t_sel} {m_sel}")
    run(session, f"hide atoms {t_sel} {m_sel}")
    run(session, "delete water")
    
    # ------------------------------
    # 4. 链匹配与数据准备
    # ------------------------------
    def build_chain_map(model, atom_names):
        chain_map = {}
        for atom in model.atoms:
            if atom.name in atom_names:
                cid = atom.chain_id
                key = (atom.residue.number, atom.residue.insertion_code)
                if cid not in chain_map:
                    chain_map[cid] = {}
                if key not in chain_map[cid]:
                    chain_map[cid][key] = []
                chain_map[cid][key].append(np.array(atom.coord))
        return chain_map

    t_map = build_chain_map(m_target, target_atom_names)
    m_map = build_chain_map(m_mobile, target_atom_names)
    
    matched_chains = {}
    used_m_chains = set()

    target_chains = list(t_map.keys())
    mobile_chains = list(m_map.keys())
    
    # 自动匹配链 (寻找最小 RMSD 对)
    for t_chain in target_chains:
        best_rmsd = float('inf')
        best_m_chain = None
        
        t_res_keys = set(t_map[t_chain].keys())
        
        for m_chain in mobile_chains:
            if m_chain in used_m_chains:
                continue
            
            m_res_keys = set(m_map[m_chain].keys())
            common_res = sorted(list(t_res_keys & m_res_keys))
            
            if not common_res:
                continue
            
            sq_diffs = []
            for res in common_res:
                coords_t = t_map[t_chain][res]
                coords_m = m_map[m_chain][res]
                n_atoms = min(len(coords_t), len(coords_m))
                for i in range(n_atoms):
                    sq_diffs.append(np.sum((coords_t[i] - coords_m[i])**2))
            
            if sq_diffs:
                rmsd = np.sqrt(sum(sq_diffs) / len(sq_diffs))
                if rmsd < best_rmsd:
                    best_rmsd = rmsd
                    best_m_chain = m_chain
        
        if best_m_chain:
            matched_chains[t_chain] = best_m_chain
            used_m_chains.add(best_m_chain)

    print(f"匹配链对：{matched_chains}")

    # ------------------------------
    # 5. RMSD 计算与着色
    # ------------------------------
    log_file = "rmsd_log.txt"
    
    total_sq_diff_all = 0
    total_atoms_all = 0
    max_rmsd_overall = 0.0
    attr_name = "rmsd_val"
    
    # 设置未匹配残基为深红
    run(session, f"color #CC0000 {t_sel}")

    # 构建残基对象映射
    t_residue_map = {}
    for r in m_target.residues:
        key = (r.number, r.insertion_code)
        if r.chain_id not in t_residue_map:
            t_residue_map[r.chain_id] = {}
        t_residue_map[r.chain_id][key] = r

    with open(log_file, "w", encoding="utf-8") as logf:
        logf.write("Multi-chain RMSD Analysis Log (ChimeraX)\n")
        logf.write("==========================================\n")
        logf.write(f"Target: {m_target.name} (ID: {m_target.id_string})\n")
        logf.write(f"Mobile: {m_mobile.name} (ID: {m_mobile.id_string})\n")
        logf.write(f"Matched chains: {matched_chains}\n\n")

        for t_chain, m_chain in matched_chains.items():
            t_cmap = t_map[t_chain]
            m_cmap = m_map[m_chain]
            
            common_res = sorted(list(set(t_cmap.keys()) & set(m_cmap.keys())))
            
            res_rmsd = {}
            max_rmsd_chain = 0.0
            chain_sq_diff = 0.0
            chain_atom_count = 0
            
            for res in common_res:
                coords_t = t_cmap[res]
                coords_m = m_cmap[res]
                n_atoms = min(len(coords_t), len(coords_m))
                
                sq_diff_res = [np.sum((coords_t[i] - coords_m[i])**2) for i in range(n_atoms)]
                rms_res = np.sqrt(sum(sq_diff_res) / n_atoms)
                
                res_rmsd[res] = rms_res
                
                chain_sq_diff += sum(sq_diff_res)
                chain_atom_count += n_atoms
                total_sq_diff_all += sum(sq_diff_res)
                total_atoms_all += n_atoms
                
                if rms_res > max_rmsd_chain:
                    max_rmsd_chain = rms_res
                if rms_res > max_rmsd_overall:
                    max_rmsd_overall = rms_res
                
                # 写入属性
                if t_chain in t_residue_map and res in t_residue_map[t_chain]:
                    res_obj = t_residue_map[t_chain][res]
                    for atom in res_obj.atoms:
                        atom.attributes[attr_name] = rms_res

            # 链 RMSD
            if chain_atom_count > 0:
                chain_rmsd = np.sqrt(chain_sq_diff / chain_atom_count)
            else:
                chain_rmsd = 0.0
            logf.write(f"Chain {t_chain} (mobile {m_chain}) RMSD: {chain_rmsd:.3f} Å, {chain_atom_count} atoms\n")

            # 保存文件
            if out_prefix:
                out_prefix_clean = out_prefix.strip('"').strip("'")
                out_file = f"{out_prefix_clean}_{t_chain}.txt"
                with open(out_file, "w", encoding="utf-8") as f:
                    f.write("Residue\tRMSD(A)\n")
                    for r_key, rms in res_rmsd.items():
                        r_str = f"{r_key[0]}{r_key[1]}"
                        f.write(f"{r_str}\t{rms:.3f}\n")
                print(f"链 {t_chain} RMSD 已保存到 {out_file}")

        # 全局 RMSD
        if total_atoms_all > 0:
            global_rmsd = np.sqrt(total_sq_diff_all / total_atoms_all)
            logf.write(f"\nGlobal RMSD (all matched atoms): {global_rmsd:.3f} Å, total atoms: {total_atoms_all}\n")
            print(f"全局 RMSD: {global_rmsd:.3f} Å, total atoms: {total_atoms_all}")
        else:
            logf.write("No matched atoms found for global RMSD.\n")

    # ------------------------------
    # 6. 应用颜色和图例
    # ------------------------------
    if max_rmsd_overall > 0:
        run(session, f"color byattribute {attr_name} {t_sel} palette blue:white:red range 0,{max_rmsd_overall}")
        run(session, "colorkey")
        print("全局 RMSD 色阶图例（蓝→白→红）已生成。")
    else:
        print("未收集到匹配残基，无法计算 RMSD 和生成热图。")

# 注册命令
rmsd_desc = CmdDesc(
    required=[],
    optional=[("target", StringArg), ("mobile", StringArg)],
    keyword=[("selection", StringArg), ("out_prefix", StringArg)],
    synopsis="Calculate multi-chain RMSD, color heatmap, and generate logs."
)
register("rmsd_multi_chain_heatmap_log", rmsd_desc, rmsd_multi_chain_heatmap_log)