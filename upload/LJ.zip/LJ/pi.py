#!/usr/bin/env python
"""
ChimeraX π-π堆积相互作用分析 - 支持双选择集版本
修正版：使用RestOfLine处理选择器参数
修复：模型编号冲突问题
"""

from chimerax.core.commands import run, register, CmdDesc, FloatArg, StringArg, RestOfLine
import numpy as np
import os
import re
from datetime import datetime

# 全局变量
CENTROID_MODEL = None 
MARKER_FILE = "pi_markers.pdb"

def pi_pi_cmd(session, arg_string=None):
    """π-π分析命令接口 - 使用RestOfLine解析整个命令字符串"""
    if not arg_string:
        # 没有参数，使用默认分析所有
        return pi_pi_analysis(session, 4.5, 30.0, None, None)
    
    # 解析参数字符串
    distance = 4.5
    angle = 30.0
    selection1 = None
    selection2 = None
    
    # 解析参数
    tokens = arg_string.split()
    i = 0
    while i < len(tokens):
        token = tokens[i]
        
        if token == "distance" and i + 1 < len(tokens):
            try:
                distance = float(tokens[i + 1])
                i += 2
            except:
                print(f"警告：无法解析距离参数 {tokens[i + 1]}")
                i += 2
        elif token == "angle" and i + 1 < len(tokens):
            try:
                angle = float(tokens[i + 1])
                i += 2
            except:
                print(f"警告：无法解析角度参数 {tokens[i + 1]}")
                i += 2
        elif token == "target" and i + 1 < len(tokens):
            # 处理target参数
            selection2 = tokens[i + 1]
            i += 2
        elif selection1 is None:
            # 第一个非关键字参数作为selection1
            selection1 = token
            i += 1
        else:
            # 未知参数，跳过
            i += 1
    
    print(f"解析结果: selection1={selection1}, selection2={selection2}, distance={distance}, angle={angle}")
    return pi_pi_analysis(session, distance, angle, selection1, selection2)

def pi_pi_analysis(session, distance=4.5, angle=30.0, selection1=None, selection2=None):
    """分析π-π相互作用的主函数，支持单/双选择集"""
    global CENTROID_MODEL
    
    print("="*60)
    print("开始π-π堆积相互作用分析 (双选择集版)")
    print(f"参数: 距离≤{distance}Å, 角度≤{angle}°")
    
    if selection1:
        print(f"选择集1: {selection1}")
    if selection2:
        print(f"选择集2: {selection2}")
    print("="*60)
    
    # 1. 清理环境
    cleanup(session)
    
    # 获取芳香残基（根据选择集模式）
    residues1, residues2 = get_aromatic_residues_by_selection(session, selection1, selection2)
    
    if not residues1:
        print("没有找到芳香残基")
        return []
    
    print(f"选择集1找到 {len(residues1)} 个芳香残基")
    if residues2 is not None:
        print(f"选择集2找到 {len(residues2)} 个芳香残基")
    
    # 2. 计算质心并生成PDB
    all_residues = residues1
    if residues2 is not None:
        all_residues = residues1 + residues2
    
    residue_to_index = create_pdb_markers_robust(session, all_residues)
    
    # 3. 打开临时PDB文件
    try:
        # 删除可能存在的旧标记模型
        from chimerax.atomic import all_atomic_structures
        for m in list(all_atomic_structures(session)):
            if m.name == "PiCentroids":
                try:
                    session.models.close([m])
                except:
                    pass
        
        # 打开新的标记模型
        run(session, f"open {MARKER_FILE} name PiCentroids")
        
        # 重新查找所有PiCentroids模型，获取最新的那个
        centroid_models = []
        for m in all_atomic_structures(session):
            if m.name == "PiCentroids":
                centroid_models.append(m)
        
        if not centroid_models:
            print("错误：PDB文件加载失败")
            return
        
        # 获取最后一个（最新的）模型
        CENTROID_MODEL = centroid_models[-1]
        print(f"成功加载质心模型: #{CENTROID_MODEL.id_string}")
        
    except Exception as e:
        print(f"加载质心模型失败: {e}")
        return

    # 4. 重建映射
    centroids = {}
    atoms = list(CENTROID_MODEL.atoms)
    
    for res, idx in residue_to_index.items():
        found_atom = None
        for atom in atoms:
            if atom.serial_number == idx:
                found_atom = atom
                break
        if found_atom:
            centroids[res] = found_atom
        else:
            print(f"警告：未找到残基 {res.chain_id}:{res.number}({res.name}) 对应的质心原子")

    # 5. 查找相互作用（支持双选择集模式）
    interactions = find_interactions_between_selections(centroids, residues1, residues2, distance, angle)
    
    if interactions:
        print(f"找到 {len(interactions)} 个π-π相互作用")
        
        # 6. 删除未参与互作的质心原子
        filter_centroids(session, interactions, CENTROID_MODEL)
        
        # 7. 可视化
        visualize_interactions(session, interactions, CENTROID_MODEL)
        
        # 8. 保存结果
        save_results_to_file(interactions, distance, angle)
        
        # 9. 高亮残基
        highlight_and_clean(session, interactions)
        
        # 10. 优化显示
        optimize_display(session, interactions, centroids)
    else:
        print("没有找到满足条件的π-π相互作用")
    
    return interactions

def get_aromatic_residues_by_selection(session, selection1=None, selection2=None):
    """根据选择器获取芳香残基，支持双选择集"""
    from chimerax.atomic import selected_atoms
    
    def get_residues_from_selector(selector):
        """从选择器字符串获取芳香残基"""
        if not selector:
            return []
        
        try:
            # 执行选择命令
            run(session, f"select {selector}")
            sel_atoms = selected_atoms(session)
            
            residues = []
            seen = set()
            for atom in sel_atoms:
                res = atom.residue
                if (res.name in ['PHE', 'TYR', 'TRP', 'HIS'] and 
                    res not in seen and
                    hasattr(res, 'polymer_type') and
                    res.polymer_type == res.PT_AMINO):
                    residues.append(res)
                    seen.add(res)
            
            run(session, "select clear")
            return residues
        except Exception as e:
            print(f"选择器错误: {selector} - {e}")
            return []
    
    # 如果没有提供选择集，获取当前选择或所有
    if selection1 is None:
        from chimerax.atomic import selected_atoms
        sel_atoms = selected_atoms(session)
        if sel_atoms:
            # 使用当前选择
            print("使用当前选择")
            residues1 = []
            seen = set()
            for atom in sel_atoms:
                res = atom.residue
                if (res.name in ['PHE', 'TYR', 'TRP', 'HIS'] and 
                    res not in seen and
                    hasattr(res, 'polymer_type') and
                    res.polymer_type == res.PT_AMINO):
                    residues1.append(res)
                    seen.add(res)
        else:
            # 获取所有芳香残基
            print("分析所有芳香残基")
            residues1 = get_all_aromatic_residues(session)
    else:
        residues1 = get_residues_from_selector(selection1)
    
    # 获取第二个选择集的残基（如果提供了）
    residues2 = None
    if selection2:
        residues2 = get_residues_from_selector(selection2)
    
    return residues1, residues2

def get_all_aromatic_residues(session):
    """获取所有芳香残基"""
    from chimerax.atomic import all_atomic_structures
    residues = []
    seen = set()
    
    for model in all_atomic_structures(session):
        if hasattr(model, 'residues'):
            for res in model.residues:
                if (res.name in ['PHE', 'TYR', 'TRP', 'HIS'] and 
                    res not in seen and
                    hasattr(res, 'polymer_type') and
                    res.polymer_type == res.PT_AMINO):
                    residues.append(res)
                    seen.add(res)
    
    return residues

def find_interactions_between_selections(centroids, residues1, residues2, max_distance, max_angle):
    """查找两个选择集之间的π-π相互作用"""
    interactions = []
    
    # 如果residues2为None，则分析选择集1内部的相互作用
    if residues2 is None:
        residues2 = residues1
        print(f"正在分析 {len(residues1)} 个芳香残基内部的相互作用...")
        
        for i in range(len(residues1)):
            for j in range(i+1, len(residues2)):
                res1 = residues1[i]
                res2 = residues2[j]
                
                # 跳过同一链且相邻的残基（可选）
                if (res1.chain_id == res2.chain_id and 
                    abs(res1.number - res2.number) <= 2):
                    continue
                
                # 检查两个残基是否都在centroids字典中
                if res1 not in centroids or res2 not in centroids:
                    continue
                    
                atom1 = centroids[res1]
                atom2 = centroids[res2]
                dist = np.linalg.norm(atom1.coord - atom2.coord)
                
                if dist <= max_distance:
                    angle = calculate_pymol_like_angle(res1, res2)
                    if angle <= max_angle or angle >= (180 - max_angle):
                        interactions.append({
                            'res1': res1, 'res2': res2,
                            'distance': dist, 'angle': angle,
                            'atom1': atom1, 'atom2': atom2
                        })
    else:
        # 分析两个不同选择集之间的相互作用
        print(f"正在分析选择集1({len(residues1)})和选择集2({len(residues2)})之间的相互作用...")
        
        for res1 in residues1:
            for res2 in residues2:
                # 跳过同一个残基（理论上不会发生，因为来自不同选择集）
                if res1 == res2:
                    continue
                
                # 检查两个残基是否都在centroids字典中
                if res1 not in centroids or res2 not in centroids:
                    continue
                    
                atom1 = centroids[res1]
                atom2 = centroids[res2]
                dist = np.linalg.norm(atom1.coord - atom2.coord)
                
                if dist <= max_distance:
                    angle = calculate_pymol_like_angle(res1, res2)
                    if angle <= max_angle or angle >= (180 - max_angle):
                        interactions.append({
                            'res1': res1, 'res2': res2,
                            'distance': dist, 'angle': angle,
                            'atom1': atom1, 'atom2': atom2
                        })
    
    return interactions

def cleanup(session):
    """清理"""
    global CENTROID_MODEL
    
    try:
        run(session, "delete distances")
        run(session, "delete labels")
        
        # 清除所有旧的PiCentroids模型
        from chimerax.atomic import all_atomic_structures
        for m in list(all_atomic_structures(session)):
            if m.name == "PiCentroids":
                try:
                    session.models.close([m])
                except:
                    pass
        
        CENTROID_MODEL = None
        
        if os.path.exists(MARKER_FILE):
            try:
                os.remove(MARKER_FILE)
            except:
                pass
    except Exception as e:
        print(f"清理时出现警告: {e}")

def create_pdb_markers_robust(session, residues):
    """生成绝对精确的PDB文件 - 修正质心计算与PyMOL一致"""
    residue_map = {}
    lines = []
    
    print("正在计算质心并生成绝对精确PDB文件...")
    
    idx = 1
    for res in residues:
        # 获取特定芳香环原子（与PyMOL一致）
        ring_atoms = get_specific_ring_atoms(res)
        
        if not ring_atoms:
            # 如果没有找到特定原子，使用所有非氢原子
            for atom in res.atoms:
                if atom.element.name != 'H' and not atom.name.startswith('H'):
                    ring_atoms.append(atom)
        
        if ring_atoms:
            # 计算质心 - 与PyMOL的centerofmass类似（几何中心）
            coords = np.array([atom.scene_coord for atom in ring_atoms])
            center = np.mean(coords, axis=0)
            x, y, z = center[0], center[1], center[2]
            
            # PDB格式
            part1 = "ATOM  "
            part2 = f"{idx:5d}"
            part3 = "  "
            part4 = "CA  "
            part5 = "GLY"
            part6 = " A"
            part7 = f"{idx:4d}"
            part8 = "    "
            part9 = f"{x:8.3f}{y:8.3f}{z:8.3f}"
            part10 = f"  1.00  0.10"
            part11 = "          C  "
            line = part1 + part2 + part3 + part4 + part5 + part6 + part7 + part8 + part9 + part10 + part11
            line = (line + " " * 80)[:80]
            lines.append(line)
            residue_map[res] = idx
            idx += 1
            
    with open(MARKER_FILE, 'w') as f:
        for line in lines:
            f.write(line + "\n")
        f.write("END\n")
        
    return residue_map

def get_specific_ring_atoms(residue):
    """获取精确的芳香环原子列表 - 与PyMOL保持一致"""
    atoms = []
    if residue.name == 'PHE':
        # PHE: CG+CD1+CE1+CZ+CE2+CD2 (与PyMOL完全一致)
        atoms_order = ['CG', 'CD1', 'CE1', 'CZ', 'CE2', 'CD2']
    elif residue.name == 'TYR':
        # TYR: CG+CD1+CE1+CZ+CE2+CD2 (与PyMOL完全一致)
        atoms_order = ['CG', 'CD1', 'CE1', 'CZ', 'CE2', 'CD2']
    elif residue.name == 'TRP':
        # TRP: CH2+CZ3+CE3+CZ2+CE2+CD2 (与PyMOL完全一致)
        atoms_order = ['CH2', 'CZ3', 'CE3', 'CZ2', 'CE2', 'CD2']
    elif residue.name == 'HIS':
        # HIS: CG+ND1+CE1+NE2+CD2 (与PyMOL完全一致)
        atoms_order = ['CG', 'ND1', 'CE1', 'NE2', 'CD2']
    else:
        return []
    
    for atom_name in atoms_order:
        atom = residue.find_atom(atom_name)
        if atom:
            atoms.append(atom)
    return atoms

def calculate_pymol_like_angle(res1, res2):
    """使用PyMOL方法计算π-π角度"""
    try:
        # 获取特定环原子（与PyMOL一致）
        atoms1 = get_specific_ring_atoms(res1)
        atoms2 = get_specific_ring_atoms(res2)
        
        if len(atoms1) < 3 or len(atoms2) < 3:
            return 0.0
        
        # 取前三个原子计算法向量（与PyMOL一致）
        # PyMOL使用这三个原子：第一个、第二个、第三个
        x1 = atoms1[0].scene_coord
        x2 = atoms1[1].scene_coord
        x3 = atoms1[2].scene_coord
        
        y1 = atoms2[0].scene_coord
        y2 = atoms2[1].scene_coord
        y3 = atoms2[2].scene_coord
        
        # 计算第一个平面的法向量
        B1, B2, B3 = x1[0] - x2[0], x1[1] - x2[1], x1[2] - x2[2]
        C1, C2, C3 = x1[0] - x3[0], x1[1] - x3[1], x1[2] - x3[2]
        n1 = np.array([B2 * C3 - C2 * B3, 
                      B3 * C1 - C3 * B1, 
                      B1 * C2 - C1 * B2])
        
        # 计算第二个平面的法向量
        D1, D2, D3 = y1[0] - y2[0], y1[1] - y2[1], y1[2] - y2[2]
        E1, E2, E3 = y1[0] - y3[0], y1[1] - y3[1], y1[2] - y3[2]
        n2 = np.array([D2 * E3 - E2 * D3, 
                      D3 * E1 - E3 * D1, 
                      D1 * E2 - E1 * D2])
        
        # 计算角度（与PyMOL完全一致）
        dot_product = np.dot(n1, n2)
        magnitude1 = np.linalg.norm(n1)
        magnitude2 = np.linalg.norm(n2)
        
        # 避免除零错误
        if magnitude1 == 0 or magnitude2 == 0:
            return 0.0
        
        cos_angle = dot_product / (magnitude1 * magnitude2)
        # 确保cos_angle在有效范围内
        cos_angle = np.clip(cos_angle, -1.0, 1.0)
        
        rad_angle = np.arccos(cos_angle)
        degree = np.degrees(rad_angle)
        
        # 如果角度大于90度，取180-角度（锐角）
        if degree > 90:
            degree = 180 - degree
        
        return round(degree, 2)
    except Exception as e:
        print(f"计算角度时出错: {e}")
        return 0.0

def filter_centroids(session, interactions, model):
    """删除未参与互作的质心原子"""
    print("\n正在清理未参与互作的质心原子...")
    involved_serials = set()
    for inter in interactions:
        involved_serials.add(inter['atom1'].serial_number)
        involved_serials.add(inter['atom2'].serial_number)
    
    # 收集需要删除的原子序号
    serials_to_delete = []
    for atom in model.atoms:
        if atom.serial_number not in involved_serials:
            serials_to_delete.append(str(atom.serial_number))
    
    if serials_to_delete:
        # 构建逗号分隔的序号字符串
        serial_str = ",".join(serials_to_delete)
        
        # 使用 run 命令批量删除
        delete_cmd = f"delete #{model.id_string} /A:{serial_str}"
        
        try:
            run(session, delete_cmd)
            print(f"已删除 {len(serials_to_delete)} 个未参与互作的质心。")
        except Exception as e:
            print(f"删除失败 (可能原子已被删除): {e}")

def visualize_interactions(session, interactions, model):
    """可视化"""
    print("\n正在绘制连线...")
    
    try: run(session, "delete distances")
    except: pass
    try: run(session, "delete labels")
    except: pass
    
    for i, inter in enumerate(interactions, 1):
        atom1 = inter['atom1']
        atom2 = inter['atom2']
        dist = inter['distance']
        
        spec1 = f"#{model.id_string}/A:{atom1.residue.number}@{atom1.name}"
        spec2 = f"#{model.id_string}/A:{atom2.residue.number}@{atom2.name}"
        
        try:
            run(session, f"distance {spec1} {spec2} color cyan radius 0.05 dashes 5")           
        except Exception as e:
            print(f"(绘制连线失败: {e})")

def save_results_to_file(interactions, distance_cutoff, angle_cutoff):
    """保存结果"""
    from datetime import datetime
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f"pi_pi_results_{timestamp}.txt"
    with open(filename, 'w', encoding='utf-8') as f:
        f.write("="*60 + "\n" + "π-π堆积相互作用分析报告\n" + "="*60 + "\n\n")
        f.write(f"分析时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"距离阈值: {distance_cutoff} Å\n")
        f.write(f"角度阈值: {angle_cutoff} °\n")
        f.write(f"总相互作用数: {len(interactions)}\n\n")
        for i, inter in enumerate(interactions, 1):
            res1 = inter['res1']
            res2 = inter['res2']
            f.write(f"{i}. {res1.chain_id}:{res1.number}({res1.name}) ↔ {res2.chain_id}:{res2.number}({res2.name})\n")
            f.write(f"   质心距离: {inter['distance']:.2f} Å, 平面夹角: {inter['angle']:.1f} °\n\n")
    print(f"\n结果已保存到: {filename}")

def highlight_and_clean(session, interactions):
    """高亮显示"""
    residues = set()
    for inter in interactions:
        residues.add(inter['res1'])
        residues.add(inter['res2'])
    if residues:
        run(session, "select clear")
        for res in residues:
            run(session, f"select add #{res.structure.id_string}/{res.chain_id}:{res.number}")
        run(session, "show (sel-residues & sidechain) target ab")
        run(session, "color sel byhetero")
        run(session, "select ~sel")
        run(session, "hide (sel) & sidechain")
        run(session, "select clear")
        for res in residues:
            run(session, f"select add #{res.structure.id_string}/{res.chain_id}:{res.number}")
        run(session, "style sel stick")
        print(f"已高亮显示 {len(residues)} 个涉及π-π相互作用的残基")

def optimize_display(session, interactions, centroids):
    """设置透明质心"""
    global CENTROID_MODEL
    if not interactions: return
    
    try:
        run(session, f"display #{CENTROID_MODEL.id_string}")
        run(session, f"hide #{CENTROID_MODEL.id_string} cartoon")
        run(session, f"show #{CENTROID_MODEL.id_string} atom")
        run(session, f"transparency #{CENTROID_MODEL.id_string} 100 atom")
    except Exception as e:
        print(f"设置透明度警告: {e}")

def register_pi_pi_command(session):
    """注册π-π分析命令 - 使用RestOfLine处理所有参数"""
    desc = CmdDesc(
        optional=[('arg_string', RestOfLine)],
        synopsis='分析π-π堆积相互作用 (支持双选择集)'
    )
    
    # 尝试取消注册已存在的命令
    try:
        from chimerax.core.commands import unregister
        unregister('pi_pi')
        print("已卸载旧版 pi_pi 命令")
    except:
        pass
    
    register('pi_pi', desc, pi_pi_cmd, logger=session.logger)
    print("命令 'pi_pi' 已注册 (支持双选择集模式)！")

# 注册命令
try: 
    register_pi_pi_command(session)
except Exception as e: 
    print(f"注册命令失败: {e}")

def run_pi_pi():
    """兼容旧版的运行函数"""
    pi_pi_analysis(session)