#!/usr/bin/env python3

import tkinter as tk
from tkinter import filedialog, ttk, scrolledtext
import subprocess
import os
import sys

class SimpleRunner:
    def __init__(self, root):
        self.root = root
        self.root.title("Simple Script Runner")
        self.root.geometry("600x400")
        
        # Create main frame
        self.main_frame = ttk.Frame(root, padding="10")
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Script path
        ttk.Label(self.main_frame, text="Script Path:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.script_path_var = tk.StringVar()
        ttk.Entry(self.main_frame, textvariable=self.script_path_var, width=50).grid(row=0, column=1, sticky=tk.W, pady=5, padx=5)
        ttk.Button(self.main_frame, text="Browse", command=self.browse_script).grid(row=0, column=2, pady=5, padx=5)
        
        # Parameters
        ttk.Label(self.main_frame, text="Parameters:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.params_var = tk.StringVar()
        ttk.Entry(self.main_frame, textvariable=self.params_var, width=50).grid(row=1, column=1, sticky=tk.W, pady=5, padx=5)
        
        # Run button
        self.run_button = ttk.Button(self.main_frame, text="Run Script", command=self.run_script)
        self.run_button.grid(row=2, column=0, columnspan=3, pady=10)
        
        # Output
        output_frame = ttk.LabelFrame(self.main_frame, text="Output", padding="10")
        output_frame.grid(row=3, column=0, columnspan=3, sticky=tk.NSEW, pady=5)
        self.main_frame.grid_rowconfigure(3, weight=1)
        self.main_frame.grid_columnconfigure(1, weight=1)
        
        self.output_text = scrolledtext.ScrolledText(output_frame, height=10, wrap=tk.WORD)
        self.output_text.pack(fill=tk.BOTH, expand=True)
    
    def browse_script(self):
        """Browse script files"""
        filetypes = [("Python Scripts", "*.py"), ("All Files", "*.*")]
        filename = filedialog.askopenfilename(title="Select Script File", filetypes=filetypes)
        if filename:
            self.script_path_var.set(filename)
    
    def run_script(self):
        """Run script"""
        script_path = self.script_path_var.get()
        if not script_path:
            self.append_output("Error: Please select script file\n")
            return
        
        if not os.path.exists(script_path):
            self.append_output(f"Error: Script file does not exist: {script_path}\n")
            return
        
        # Prepare command
        cmd = [sys.executable, script_path] if script_path.endswith('.py') else [script_path]
        
        # Add parameters
        params = self.params_var.get().strip()
        if params:
            cmd.extend(params.split())
        
        # Show command
        self.append_output(f"Running: {' '.join(cmd)}\n")
        self.append_output("-" * 50 + "\n")
        
        # Run script
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                cwd=os.getcwd()
            )
            self.append_output(result.stdout)
            if result.stderr:
                self.append_output(f"Error: {result.stderr}\n")
            self.append_output(f"\nScript completed (Exit code: {result.returncode})\n")
        except Exception as e:
            self.append_output(f"Error: {str(e)}\n")
    
    def append_output(self, text):
        """Append output"""
        self.output_text.insert(tk.END, text)
        self.output_text.see(tk.END)

if __name__ == "__main__":
    root = tk.Tk()
    app = SimpleRunner(root)
    root.mainloop()