import json
from chimerax.core.commands import run

# -----------------------------
# 配置
json_file = r"D:/script/fab2.json"
contact_color = "yellow"
hbond_color = "cyan"

# 重链红系，轻链蓝系
cdr_colors = {
    "H_CDR1": "#b39ddb",
    "H_CDR2": "#9575cd",
    "H_CDR3": "#7e57c2",
    "L_CDR1": "#64b5f6",  # 轻链L或K
    "L_CDR2": "#42a5f5",
    "L_CDR3": "#2196f3",
    "K_CDR1": "#64b5f6",  # 兼容JSON里轻链用K的情况
    "K_CDR2": "#42a5f5",
    "K_CDR3": "#2196f3"
}

# -----------------------------
# 读取 JSON
with open(json_file, "r", encoding="utf-8") as f:
    cdr_data = json.load(f)

# -----------------------------
# 检查模型
if not session.models.list():
    print("未检测到打开的 PDB 文件")
    exit(1)

# 初始显示设置
run(session, "set bgColor white")
run(session, "hide atoms")
run(session, "show cartoons")
run(session, "style stick")

model1 = session.models.list()[0]  # 原始模型 #1

# -----------------------------
# 清理之前的复制模型，保持 #1 不动
for m in session.models.list()[1:]:
    m.delete()

# -----------------------------
# 获取链信息
chains = {c.chain_id: c for c in model1.chains}

fab_chain_map = {}  # JSON链 -> PDB链
offset_map = {}     # JSON链 -> PDB残基起始偏移

for json_chain, data in cdr_data.items():
    if not data:
        continue
    best_match = None
    best_diff = 1e6
    json_len = data.get("sequence_length", 0)
    for cid, chain in chains.items():
        diff = abs(len(chain.residues) - json_len)
        if diff < best_diff:
            best_diff = diff
            best_match = cid
    if best_match:
        fab_chain_map[json_chain] = best_match
        offset_map[json_chain] = chains[best_match].residues[0].number - 1
        chains.pop(best_match)

antigen_chains = list(chains.keys())
antigen_sel = " | ".join([f"/{cid}" for cid in antigen_chains])

# -----------------------------
# 复制 #1 → #2~#8
for i in range(7):
    run(session, "combine #1")

cdr_model_ids = list(range(2, 9))  # #2~#8

# -----------------------------
# 分配模型
model_index = 0

# #2 只保留抗原
run(session, f"sel #{cdr_model_ids[model_index]} & ~({antigen_sel})")
run(session, "delete sel")
model_index += 1

# #3~#8 每个模型保留一个 CDR
cdr_list = []
for json_chain, cdrs in cdr_data.items():
    for cdr_name, info in cdrs.get("CDRs", {}).items():
        cdr_list.append((json_chain, cdr_name, info))

# -----------------------------
# 设置 CDR 颜色
for (json_chain, cdr_name, info) in cdr_list:
    if model_index >= len(cdr_model_ids):
        break
    mdl_id = cdr_model_ids[model_index]
    pdb_chain = fab_chain_map[json_chain]
    offset = offset_map[json_chain]

    start = info.get("start")
    end = info.get("end")
    if start and end:
        start_pdb = start + offset
        end_pdb = end + offset
        sel_str = f"/{pdb_chain}:{start_pdb}-{end_pdb}"

        # 删除除当前CDR片段外的所有残基
        run(session, f"sel #{mdl_id} & ~({sel_str})")
        run(session, "delete sel")

        # ✅ 使用 JSON 的 chain_type 来判断 H 或 K/L 链
        chain_type = cdr_data[json_chain].get("chain_type", "K")  # 默认轻链
        color_key = f"{chain_type}_{cdr_name}"
        color = cdr_colors.get(color_key, "yellow")
        run(session, f"sel #{mdl_id}")
        run(session, f"color sel {color}")

    model_index += 1


# -----------------------------
# 互作分析：只执行一次
run(
    session,
    f"contacts #3-8 restrict #{cdr_model_ids[0]} select true "
    f"makePseudobonds false reveal true showDist false color {contact_color}"
)
run(
    session,
    f"hbonds #3-8 restrict #{cdr_model_ids[0]} reveal true showDist true color {hbond_color} log true"
)
