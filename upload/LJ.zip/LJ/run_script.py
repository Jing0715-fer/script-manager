#!/usr/bin/env python3

import os
import sys
import subprocess
import json
import shutil

class ScriptRunner:
    def __init__(self):
        """Initialize script runner"""
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.upload_dir = os.path.join(self.base_dir, "uploads")
        if not os.path.exists(self.upload_dir):
            os.makedirs(self.upload_dir)
        self.config_file = os.path.join(self.base_dir, "run_script_config.json")
        
    def list_scripts(self):
        """List available scripts"""
        print("Available scripts:")
        print("-" * 60)
        
        scripts = []
        script_extensions = ['.py', '.sh']
        
        # Search for scripts in current directory and subdirectories
        for root, dirs, files in os.walk(self.base_dir):
            # Skip certain directories
            dirs[:] = [d for d in dirs if d not in ['__pycache__', 'uploads']]
            
            for file in files:
                if any(file.endswith(ext) for ext in script_extensions):
                    # Skip this script itself
                    if file == os.path.basename(__file__):
                        continue
                    script_path = os.path.join(root, file)
                    scripts.append(script_path)
        
        # Also check /mnt/d/script directory
        script_dir = "/mnt/d/script"
        if os.path.exists(script_dir):
            for file in os.listdir(script_dir):
                if any(file.endswith(ext) for ext in script_extensions):
                    script_path = os.path.join(script_dir, file)
                    scripts.append(script_path)
        
        # Sort and display scripts
        scripts.sort(key=lambda x: os.path.basename(x))
        
        for i, script in enumerate(scripts, 1):
            rel_path = os.path.relpath(script, self.base_dir)
            print(f"{i:2d}. {rel_path}")
        
        print("-" * 60)
        return scripts
    
    def list_attachments(self):
        """List available attachments"""
        attachments = []
        
        if os.path.exists(self.upload_dir):
            for file in os.listdir(self.upload_dir):
                file_path = os.path.join(self.upload_dir, file)
                if os.path.isfile(file_path):
                    attachments.append(file_path)
        
        if attachments:
            print("Available attachments:")
            print("-" * 60)
            for i, attachment in enumerate(attachments, 1):
                size = os.path.getsize(attachment)
                size_str = f"{size:,} bytes"
                print(f"{i:2d}. {os.path.basename(attachment)} ({size_str})")
            print("-" * 60)
        else:
            print("No attachments available.")
        
        return attachments
    
    def detect_parameters(self, script_path):
        """Detect script parameters"""
        parameters = []
        
        try:
            with open(script_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Detect Python script parameters
            if script_path.endswith('.py'):
                # Look for argparse
                if 'argparse' in content:
                    import re
                    args = re.findall(r'add_argument\([\'"]([^"\']+)[\'"]', content)
                    if args:
                        parameters.extend([f"--{arg}" for arg in args])
                
                # Look for sys.argv
                elif 'sys.argv' in content:
                    import re
                    len_checks = re.findall(r'len\(sys\.argv\)\s*([<>=!]+)\s*(\d+)', content)
                    if len_checks:
                        required_args = int(len_checks[0][1]) - 1
                        if required_args > 0:
                            parameters.extend([f"Arg {i}" for i in range(1, required_args + 1)])
            
            # Detect Shell script parameters
            elif script_path.endswith('.sh'):
                if 'getopts' in content:
                    import re
                    opts = re.findall(r'getopts\s+([a-zA-Z]+)', content)
                    if opts:
                        for opt_string in opts:
                            for opt in opt_string:
                                parameters.append(f"-{opt}")
        
        except Exception as e:
            print(f"Warning: Error detecting parameters: {e}")
        
        return parameters
    
    def upload_file(self, file_path):
        """Upload file to attachments directory"""
        if not os.path.exists(file_path):
            print(f"Error: File not found: {file_path}")
            return False
        
        try:
            dest_path = os.path.join(self.upload_dir, os.path.basename(file_path))
            shutil.copy2(file_path, dest_path)
            print(f"Uploaded: {os.path.basename(file_path)} -> {os.path.basename(dest_path)}")
            return True
        except Exception as e:
            print(f"Error uploading file: {e}")
            return False
    
    def run_script(self, script_path, parameters):
        """Run script with given parameters"""
        if not os.path.exists(script_path):
            print(f"Error: Script not found: {script_path}")
            return
        
        print(f"\nRunning: {os.path.basename(script_path)}")
        print("-" * 60)
        
        # Prepare command
        if script_path.endswith('.py'):
            cmd = [sys.executable, script_path]
        else:
            cmd = [script_path]
        
        # Add parameters
        cmd.extend(parameters)
        
        print(f"Command: {' '.join(cmd)}")
        print(f"Working directory: {self.base_dir}")
        print("-" * 60)
        
        # Run script
        try:
            process = subprocess.Popen(
                cmd,
                cwd=self.base_dir,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1
            )
            
            # Read output
            for line in iter(process.stdout.readline, ''):
                print(line, end='')
            
            process.stdout.close()
            returncode = process.wait()
            
            print("-" * 60)
            print(f"Exit code: {returncode}")
            
            if returncode == 0:
                print("✓ Script completed successfully!")
            else:
                print("✗ Script failed with error code:", returncode)
                
        except KeyboardInterrupt:
            print("\n✗ Script interrupted by user")
            return
        except Exception as e:
            print(f"✗ Error running script: {e}")
    
    def main(self):
        """Main function"""
        print("Script Runner CLI")
        print("=" * 60)
        print("A command-line tool to run scripts without GUI")
        print("=" * 60)
        
        while True:
            print("\nOptions:")
            print("1. List available scripts")
            print("2. List attachments")
            print("3. Upload file")
            print("4. Run script")
            print("5. Exit")
            
            choice = input("\nEnter your choice (1-5): ")
            
            if choice == '1':
                self.list_scripts()
                
            elif choice == '2':
                self.list_attachments()
                
            elif choice == '3':
                file_path = input("Enter file path to upload: ")
                if file_path:
                    self.upload_file(file_path)
                    
            elif choice == '4':
                # List scripts
                scripts = self.list_scripts()
                
                if not scripts:
                    print("No scripts found.")
                    continue
                
                # Select script
                while True:
                    try:
                        script_num = int(input("\nEnter script number: "))
                        if 1 <= script_num <= len(scripts):
                            selected_script = scripts[script_num - 1]
                            break
                        else:
                            print(f"Please enter a number between 1 and {len(scripts)}")
                    except ValueError:
                        print("Please enter a valid number")
                
                print(f"\nSelected: {os.path.basename(selected_script)}")
                
                # Detect parameters
                parameters = self.detect_parameters(selected_script)
                
                # Get user input for parameters
                user_params = []
                
                if parameters:
                    print("\nParameters detected:")
                    print("-" * 60)
                    
                    for param in parameters:
                        if param.startswith('Arg'):
                            # For positional arguments
                            value = input(f"Enter value for {param}: ")
                            if value:
                                user_params.append(value)
                        else:
                            # For named arguments
                            value = input(f"Enter value for {param}: ")
                            if value:
                                user_params.append(param)
                                user_params.append(value)
                else:
                    # No parameters detected, ask for any arguments
                    args = input("Enter any additional arguments (space-separated): ")
                    if args:
                        user_params.extend(args.split())
                
                # Run script
                self.run_script(selected_script, user_params)
                
            elif choice == '5':
                print("Exiting...")
                break
                
            else:
                print("Invalid choice. Please try again.")

if __name__ == "__main__":
    runner = ScriptRunner()
    runner.main()