#!/usr/bin/env python3

import os
import sys
import subprocess

class TestCLIRunner:
    def __init__(self):
        """Initialize test CLI runner"""
        self.script_dir = os.path.dirname(os.path.abspath(__file__))
        self.upload_dir = os.path.join(self.script_dir, "uploads")
        if not os.path.exists(self.upload_dir):
            os.makedirs(self.upload_dir)
    
    def test_list_scripts(self):
        """Test listing scripts"""
        print("Testing script listing...")
        print("-" * 50)
        
        # Find Python scripts
        scripts = []
        for root, dirs, files in os.walk(self.script_dir):
            dirs[:] = [d for d in dirs if d not in ['__pycache__', 'uploads']]
            
            for file in files:
                if file.endswith('.py') and file not in ['test_cli.py', 'cli_runner.py', 'script_ui.py', 'script_runner.py']:
                    script_path = os.path.join(root, file)
                    scripts.append(script_path)
        
        if scripts:
            print(f"Found {len(scripts)} scripts:")
            for script in scripts[:5]:  # Show first 5 scripts
                print(f"  - {os.path.basename(script)}")
            if len(scripts) > 5:
                print(f"  ... and {len(scripts) - 5} more")
        else:
            print("No scripts found")
        
        print("-" * 50)
        return scripts
    
    def test_segid(self):
        """Test segID.py script"""
        print("\nTesting segID.py script...")
        print("-" * 50)
        
        # Create test PDB file
        test_pdb = """ATOM      1  N   ALA A   1      26.510  32.830  11.530  1.00  0.00           N  
ATOM      2  CA  ALA A   1      27.680  32.000  10.870  1.00  0.00           C  
ATOM      3  C   ALA A   1      27.310  30.500  10.710  1.00  0.00           C  
ATOM      4  O   ALA A   1      26.140  30.170  10.470  1.00  0.00           O  
ATOM      5  CB  ALA A   1      28.990  31.820  11.790  1.00  0.00           C  
END
"""
        
        test_pdb_path = os.path.join(self.upload_dir, "test.pdb")
        output_pdb_path = os.path.join(self.upload_dir, "test_output.pdb")
        
        # Write test PDB
        with open(test_pdb_path, "w") as f:
            f.write(test_pdb)
        
        # Run segID.py
        segid_path = "/mnt/d/script/segID.py"
        
        if os.path.exists(segid_path):
            cmd = [sys.executable, segid_path, test_pdb_path, output_pdb_path]
            
            print(f"Running: {' '.join(cmd)}")
            
            try:
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    cwd=self.script_dir
                )
                
                print(f"Exit code: {result.returncode}")
                print(f"Stdout: {result.stdout.strip()}")
                print(f"Stderr: {result.stderr.strip()}")
                
                if result.returncode == 0:
                    print("✓ segID.py test passed!")
                else:
                    print("✗ segID.py test failed!")
                    
            except Exception as e:
                print(f"Error running segID.py: {e}")
        else:
            print("segID.py not found at /mnt/d/script/segID.py")
        
        print("-" * 50)
    
    def main(self):
        """Main test function"""
        print("Testing CLI Runner")
        print("=" * 50)
        
        # Test listing scripts
        scripts = self.test_list_scripts()
        
        # Test segID.py
        self.test_segid()
        
        print("\nTest completed!")

if __name__ == "__main__":
    tester = TestCLIRunner()
    tester.main()