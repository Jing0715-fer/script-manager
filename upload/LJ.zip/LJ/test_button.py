#!/usr/bin/env python3

import tkinter as tk
from tkinter import ttk

class TestApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Button Test")
        self.root.geometry("300x200")
        
        # Create a button
        self.run_button = ttk.Button(root, text="Click Me", command=self.on_button_click)
        self.run_button.pack(pady=50)
        
        # Create a label to show status
        self.status_label = ttk.Label(root, text="Ready")
        self.status_label.pack(pady=20)
    
    def on_button_click(self):
        """Handle button click"""
        print("Button clicked!")
        self.status_label.config(text="Button clicked!")
        # Test with a simple subprocess
        import subprocess
        try:
            result = subprocess.run(["echo", "Hello World"], capture_output=True, text=True)
            print("Subprocess output:", result.stdout)
            self.status_label.config(text=f"Output: {result.stdout.strip()}")
        except Exception as e:
            print("Error:", str(e))
            self.status_label.config(text=f"Error: {str(e)}")

if __name__ == "__main__":
    print("Starting test app...")
    root = tk.Tk()
    app = TestApp(root)
    print("App created, entering main loop...")
    root.mainloop()
    print("App closed.")