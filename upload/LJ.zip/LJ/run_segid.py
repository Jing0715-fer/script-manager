#!/usr/bin/env python3

"""
Simple script to run segID.py on PDB files
Usage: python run_segid.py <input.pdb> [output.pdb]
"""

import os
import sys
import subprocess

def main():
    if len(sys.argv) < 2:
        print("Usage: python run_segid.py <input.pdb> [output.pdb]")
        print("\nExamples:")
        print("  python run_segid.py J670.pdb")
        print("  python run_segid.py uploads/fab.pdb output_clean.pdb")
        return
    
    input_pdb = sys.argv[1]
    output_pdb = sys.argv[2] if len(sys.argv) > 2 else None
    
    # Set default output if not provided
    if not output_pdb:
        base_name = os.path.splitext(os.path.basename(input_pdb))[0]
        output_pdb = f"{base_name}_clean.pdb"
    
    # Path to segID.py
    segid_path = "/mnt/d/script/segID.py"
    
    # Check if files exist
    if not os.path.exists(segid_path):
        print(f"Error: segID.py not found at {segid_path}")
        return
    
    if not os.path.exists(input_pdb):
        print(f"Error: Input file not found: {input_pdb}")
        return
    
    # Run segID.py
    print(f"Running segID.py...")
    print(f"Input:  {input_pdb}")
    print(f"Output: {output_pdb}")
    
    try:
        result = subprocess.run(
            [sys.executable, segid_path, input_pdb, output_pdb],
            capture_output=True,
            text=True,
            check=True
        )
        
        print("\n✓ Success!")
        print(result.stdout)
        
        if os.path.exists(output_pdb):
            print(f"\nOutput file created: {output_pdb}")
            print(f"File size: {os.path.getsize(output_pdb):,} bytes")
            
    except subprocess.CalledProcessError as e:
        print(f"\n✗ Error running segID.py:")
        print(f"Exit code: {e.returncode}")
        print(f"Stdout: {e.stdout}")
        print(f"Stderr: {e.stderr}")
    except Exception as e:
        print(f"\n✗ Unexpected error: {e}")

if __name__ == "__main__":
    main()