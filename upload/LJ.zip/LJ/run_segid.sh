#!/bin/bash

# segID.py runner script

echo "Running segID.py script"
echo "======================"

# Check if segID.py exists
SEGID_PATH="/mnt/d/script/segID.py"
if [ ! -f "$SEGID_PATH" ]; then
    echo "Error: segID.py not found at $SEGID_PATH"
    exit 1
fi

# Check if input file is provided
if [ $# -lt 1 ]; then
    echo "Usage: $0 <input.pdb> [output.pdb]"
    echo ""
    echo "Examples:"
    echo "  $0 J670.pdb J670_clean.pdb"
    echo "  $0 uploads/fab.pdb"
    exit 1
fi

INPUT_FILE="$1"
OUTPUT_FILE="$2"

# If no output file provided, generate one
if [ -z "$OUTPUT_FILE" ]; then
    BASE_NAME=$(basename "$INPUT_FILE" .pdb)
    OUTPUT_FILE="${BASE_NAME}_clean.pdb"
fi

# Check if input file exists
if [ ! -f "$INPUT_FILE" ]; then
    echo "Error: Input file not found: $INPUT_FILE"
    exit 1
fi

# Run segID.py
echo "Input: $INPUT_FILE"
echo "Output: $OUTPUT_FILE"
echo ""

python3 "$SEGID_PATH" "$INPUT_FILE" "$OUTPUT_FILE"

# Check if script completed successfully
if [ $? -eq 0 ]; then
    echo ""
    echo "✓ segID.py completed successfully!"
    echo "Output file: $OUTPUT_FILE"
else
    echo ""
    echo "✗ segID.py failed to run"
    exit 1
fi