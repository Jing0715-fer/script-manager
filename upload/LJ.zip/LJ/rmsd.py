from pymol import cmd

def rmsd_multi_chain_heatmap_log(target, mobile, selection="name CA", 
                                 out_prefix="rmsd"):
    selection = selection.strip('"').strip("'")
    
    # CEalign 对齐
    cmd.cealign(target, mobile)
    
    # 可视化设置
    cmd.bg_color("white")
    cmd.hide("everything", "all")
    cmd.show("cartoon", target)
    cmd.show("cartoon", mobile)
    cmd.hide("sticks", "all")
    cmd.hide("spheres", "all")
    cmd.hide("lines", "all")
    cmd.remove("resn HOH")

    target_chains = set([atom.chain for atom in cmd.get_model(f"{target} and {selection}").atom])
    mobile_chains = set([atom.chain for atom in cmd.get_model(f"{mobile} and {selection}").atom])

    matched_chains = {}
    coords_target_all = []
    coords_mobile_all = []

    # 自动匹配链
    for t_chain in target_chains:
        t_sel = f"{target} and chain {t_chain} and {selection}"
        t_atoms = cmd.get_model(t_sel).atom
        if not t_atoms:
            continue

        best_rmsd = None
        best_m_chain = None

        for m_chain in mobile_chains:
            if m_chain in matched_chains.values():
                continue
            m_sel = f"{mobile} and chain {m_chain} and {selection}"
            m_atoms = cmd.get_model(m_sel).atom
            if not m_atoms:
                continue

            t_resi = set([atom.resi for atom in t_atoms])
            m_resi = set([atom.resi for atom in m_atoms])
            common_resi = sorted(list(t_resi & m_resi))
            if not common_resi:
                continue

            coords_t = [[float(x) for x in atom.coord] for atom in t_atoms if atom.resi in common_resi]
            coords_m = [[float(x) for x in atom.coord] for atom in m_atoms if atom.resi in common_resi]
            total_diff2 = sum(sum((ta - ma)**2 for ta, ma in zip(t, m)) for t, m in zip(coords_t, coords_m))
            rmsd = (total_diff2 / len(coords_t)) ** 0.5

            if best_rmsd is None or rmsd < best_rmsd:
                best_rmsd = rmsd
                best_m_chain = m_chain

        if best_m_chain:
            matched_chains[t_chain] = best_m_chain

    print("匹配链对：", matched_chains)

    # 打开 log 文件
    log_file = "rmsd_log.txt"
    with open(log_file, "w", encoding="utf-8") as logf:
        logf.write("Multi-chain RMSD Analysis Log\n")
        logf.write("=============================\n")
        logf.write(f"Target: {target}\n")
        logf.write(f"Mobile: {mobile}\n")
        logf.write(f"Matched chains: {matched_chains}\n\n")

        max_rmsd_overall = 0.0

        for t_chain, m_chain in matched_chains.items():
            t_sel = f"{target} and chain {t_chain} and {selection}"
            m_sel = f"{mobile} and chain {m_chain} and {selection}"
            t_atoms = cmd.get_model(t_sel).atom
            m_atoms = cmd.get_model(m_sel).atom

            t_resi_set = set([atom.resi for atom in t_atoms])
            m_resi_set = set([atom.resi for atom in m_atoms])
            common_resi = sorted(list(t_resi_set & m_resi_set))

            res_rmsd = {}
            max_rmsd_chain = 0.0
            coords_t_chain = []
            coords_m_chain = []

            for resi in common_resi:
                t_coords_res = [[float(x) for x in atom.coord] for atom in t_atoms if atom.resi == resi]
                m_coords_res = [[float(x) for x in atom.coord] for atom in m_atoms if atom.resi == resi]
                diff2_res = sum(sum((ta - ma)**2 for ta, ma in zip(t, m)) for t, m in zip(t_coords_res, m_coords_res)) / len(t_coords_res)
                rms = diff2_res ** 0.5
                res_rmsd[resi] = rms
                if rms > max_rmsd_chain:
                    max_rmsd_chain = rms
                coords_t_chain.extend(t_coords_res)
                coords_m_chain.extend(m_coords_res)
                coords_target_all.extend(t_coords_res)
                coords_mobile_all.extend(m_coords_res)

            if max_rmsd_chain > max_rmsd_overall:
                max_rmsd_overall = max_rmsd_chain

            # 链 RMSD
            total_diff2_chain = sum(sum((ta - ma)**2 for ta, ma in zip(t, m)) for t, m in zip(coords_t_chain, coords_m_chain))
            chain_rmsd = (total_diff2_chain / len(coords_t_chain)) ** 0.5
            logf.write(f"Chain {t_chain} (mobile {m_chain}) RMSD: {chain_rmsd:.3f} Å, {len(coords_t_chain)} atoms\n")

            # 上色（保留未比较残基深红）
            all_resis_in_chain = set([atom.resi for atom in t_atoms])
            for resi in all_resis_in_chain:
                if resi in res_rmsd:
                    rms = res_rmsd[resi]
                    ratio = rms / max_rmsd_chain if max_rmsd_chain > 0 else 0
                    # 蓝→白→红渐变
                    if ratio <= 0.5:
                        # 蓝 → 白
                        t_ratio = ratio / 0.5
                        r = t_ratio
                        g = t_ratio
                        b = 1
                    else:
                        # 白 → 红
                        t_ratio = (ratio - 0.5) / 0.5
                        r = 1
                        g = 1 - t_ratio
                        b = 1 - t_ratio
                else:
                    r, g, b = 0.8, 0, 0  # 未比较残基深红
                color_name = f"rmsd_{t_chain}_{resi}"
                cmd.set_color(color_name, [r, g, b])
                cmd.color(color_name, f"{target} and chain {t_chain} and resi {resi}")

            # 保存每条链 RMSD 文件
            if out_prefix:
                out_prefix_clean = out_prefix.strip('"').strip("'")
                out_file = f"{out_prefix_clean}_{t_chain}.txt"
                with open(out_file, "w", encoding="utf-8") as f:
                    f.write("Residue\tRMSD(A)\n")
                    for resi, rms in res_rmsd.items():
                        f.write(f"{resi}\t{rms:.3f}\n")
                print(f"链 {t_chain} RMSD 已保存到 {out_file}")

        # 全局 RMSD 竖直色阶图例（蓝→白→红）
        if coords_target_all and coords_mobile_all:
            total_diff2_all = sum(sum((ta - ma)**2 for ta, ma in zip(t, m)) for t, m in zip(coords_target_all, coords_mobile_all))
            global_rmsd = (total_diff2_all / len(coords_target_all)) ** 0.5
            logf.write(f"\nGlobal RMSD (all matched αC atoms): {global_rmsd:.3f} Å, total atoms: {len(coords_target_all)}\n")
            print(f"全局 RMSD: {global_rmsd:.3f} Å, total atoms: {len(coords_target_all)}")

            # dummy 对象
            cmd.pseudoatom("rmsd_key_dummy", pos=[0,0,0])
            cmd.show("spheres", "rmsd_key_dummy")
            cmd.set("sphere_scale", 0.1, "rmsd_key_dummy")

            # 设置三色
            cmd.set_color("rmsd_blue", [0,0,1])
            cmd.set_color("rmsd_white", [1,1,1])
            cmd.set_color("rmsd_red", [1,0,0])

            cmd.ramp_new("rmsd_ramp", "rmsd_key_dummy",
                         [0, max_rmsd_overall/2, max_rmsd_overall],
                         ["rmsd_blue", "rmsd_white", "rmsd_red"])

            cmd.show("surface", "rmsd_key_dummy")
            cmd.color("rmsd_ramp", "rmsd_key_dummy")
            cmd.set("transparency", 0.0, "rmsd_key_dummy")

            # 竖直条
            cmd.translate([20, 0, 0], "rmsd_key_dummy")
            cmd.scale([0.5, 0.5, 10.0], "rmsd_key_dummy")

            # 标注最小和最大
            cmd.pseudoatom("rmsd_label_min", pos=[20,0,0])
            cmd.pseudoatom("rmsd_label_max", pos=[20,0,10])
            cmd.label("rmsd_label_min", '"0.0 Å"')
            cmd.label("rmsd_label_max", f'"{max_rmsd_overall:.2f} Å"')

            print("全局 RMSD 竖直色阶图例（蓝→白→红）已生成。")
        else:
            logf.write("No matched atoms found for global RMSD.\n")
            print("未收集到匹配残基，无法计算全局 RMSD。")

cmd.extend("rmsd_multi_chain_heatmap_log", rmsd_multi_chain_heatmap_log)

#rmsd_multi_chain_heatmap_log CD16-95_model-2508018-coot-0, 1t83, selection="name CA", out_prefix=per_res_rmsd

