#!/usr/bin/env python3
"""
测试脚本 - 用于验证脚本运行器的功能

使用方法：
1. 在脚本运行器中选择此脚本
2. 输入参数：--name 测试 --count 5
3. 运行脚本查看输出
"""

import argparse
import time
import random

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='测试脚本')
    parser.add_argument('--name', type=str, default='World', help='名称')
    parser.add_argument('--count', type=int, default=3, help='循环次数')
    parser.add_argument('--delay', type=float, default=0.5, help='延迟时间')
    
    args = parser.parse_args()
    
    print(f"=== 测试脚本启动 ===")
    print(f"Hello, {args.name}!")
    print(f"循环次数: {args.count}")
    print(f"延迟时间: {args.delay}秒")
    print(f"当前时间: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    for i in range(1, args.count + 1):
        print(f"循环 {i}/{args.count}")
        print(f"随机数: {random.random():.4f}")
        print(f"时间戳: {time.time():.2f}")
        
        if i < args.count:
            print(f"等待 {args.delay} 秒...")
            time.sleep(args.delay)
        print()
    
    print(f"=== 测试脚本完成 ===")
    print(f"总共运行了 {args.count} 次循环")
    print(f"结束时间: {time.strftime('%Y-%m-%d %H:%M:%S')}")

if __name__ == "__main__":
    main()