# Script Runner CLI Tools

由于 GUI 界面在某些环境中可能无法正常工作，这里提供了基于命令行的解决方案，让您可以在任何终端环境中运行脚本。

## 工具列表

### 1. `run_segid.py` - 运行 segID.py 脚本
专门用于运行 `segID.py` 脚本，处理 PDB 文件的 Segment Identifier。

### 2. `segid_runner.py` - 交互式 segID 运行器
提供交互式界面来选择 PDB 文件并运行 `segID.py`。

### 3. `run_script.py` - 通用脚本运行器
一个功能完整的命令行工具，可以运行任何脚本文件。

## 使用方法

### 1. 运行 segID.py 处理 PDB 文件

**快速使用：**
```bash
# 处理 J670.pdb 文件，输出到 J670_clean.pdb
python run_segid.py J670.pdb

# 自定义输出文件名
python run_segid.py uploads/fab.pdb fab_clean.pdb
```

**示例输出：**
```
Running segID.py...
Input:  J670.pdb
Output: J670_clean.pdb

✓ Success!
完成！已清理Segment Identifier并保存到: J670_clean.pdb

Output file created: J670_clean.pdb
File size: 509,332 bytes
```

### 2. 使用交互式 segID 运行器

**运行：**
```bash
python segid_runner.py
```

**操作步骤：**
1. 查看可用的 PDB 文件列表
2. 输入文件编号选择要处理的 PDB 文件
3. 按 Enter 使用默认输出文件名，或输入自定义输出文件名
4. 等待脚本运行完成

### 3. 使用通用脚本运行器

**运行：**
```bash
python run_script.py
```

**功能：**
- 列出所有可用的脚本文件
- 列出可用的附件文件
- 上传文件到 attachments 目录
- 运行选定的脚本
- 支持参数输入

## 可用脚本

- `find_cdr_of_fab.py` - 查找 FAB 蛋白的 CDR 区域
- `segID.py` - 清理 PDB 文件中的 Segment Identifier
- `rename_chainid.py` - 重命名 PDB 文件中的链 ID
- 以及更多...

## 常见问题解决

### 1. GUI 界面无法打开
- 原因：在 WSL 或远程终端环境中，GUI 应用程序可能无法正常显示
- 解决方案：使用本目录中的命令行工具替代

### 2. 进程无法终止
- 原因：GUI 应用程序在某些环境中可能会卡住
- 解决方案：使用命令行工具，它们可以通过 Ctrl+C 正常终止

### 3. 找不到脚本文件
- 原因：脚本路径可能不正确
- 解决方案：使用 `run_script.py` 工具，它会自动搜索并列出所有可用的脚本

## 注意事项

1. 确保 `segID.py` 脚本位于 `/mnt/d/script/segID.py`
2. PDB 文件可以放在当前目录或 `uploads/` 目录中
3. 命令行工具支持相对路径和绝对路径
4. 所有工具都有详细的错误提示和帮助信息

## 示例工作流

1. **处理 FAB 蛋白的 CDR 区域：**
   ```bash
   python run_script.py
   # 选择 find_cdr_of_fab.py 脚本
   # 输入 FAB 蛋白的 FASTA 文件路径
   ```

2. **清理 PDB 文件的 Segment Identifier：**
   ```bash
   python run_segid.py J670.pdb
   ```

3. **重命名 PDB 文件的链 ID：**
   ```bash
   python run_script.py
   # 选择 rename_chainid.py 脚本
   # 输入 PDB 文件路径和新的链 ID
   ```

## 故障排除

如果遇到任何问题，请检查：
- Python 版本是否兼容（建议 Python 3.7+）
- 脚本路径是否正确
- 输入文件是否存在且格式正确
- 是否有足够的权限读取和写入文件

如有其他问题，请查看脚本的源代码或联系开发者。